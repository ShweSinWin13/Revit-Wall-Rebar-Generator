﻿using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using DocumentFormat.OpenXml.Drawing;
//using SkyK.MPaManager;
using Structural_WinForm_Project_Sky_K_Solution.Helpers;
using Structural_WinForm_Project_Sky_K_Solution.Helpers.RebarHelpers;
using Structural_WinForm_Project_Sky_K_Solution.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Structural_WinForm_Project_Sky_K_Solution.Service.Rebar
{
    public class RebarSetBuilder : IRebarBuilder
    {
        private readonly Document _doc;
        private Autodesk.Revit.DB.Wall _hostElement;
        private WallDto _wallDto;
        private RebarDto _rebarDto;

        // Geometry Info
        private double _wallThickness;
        private double _wallHeight;
        private XYZ _wallStartPoint;
        private XYZ _wallEndPoint;
        private XYZ _wallDirection;
        private double _wallLength;
        private double _wallBaseOffset;
        private double _wallTopOffset;

        // Cover & Faces
        private double _sideCover;
        private Face _exteriorFace;
        private Face _interiorFace;
        private XYZ _exteriorFaceNormal;
        private XYZ _interiorFaceNormal;

        // Rebar Types & Spacing
        private RebarBarType _internalHBar;
        private double _internalHBarSpacing;
        private RebarBarType _externalHBar;
        private double _externalHBarSpacing;
        private RebarBarType _internalVBar;
        private double _internalVBarSpacing;
        private RebarBarType _externalVBar;
        private double _externalVBarSpacing;
        private RebarBarType _uBar;
        private double _uBarSpacing;
        private RebarBarType _capTieBar;
        private RebarBarType _exVJointBar;
        private RebarBarType _inVJointBar;
        private RebarBarType _exHJointBar;
        private RebarBarType _inHJointBar;
        private RebarBarType _barType; // M_T2 Tie Bar Type for short walls
        private bool _isUbar;
        private UBarSide _uBarSide = UBarSide.None;

        // Hooks & Orientations
        private string _externalVStartHookType;
        private string _externalVEndHookType;
        private string _externalVStartOrientation;
        private string _externalVEndOrientation;

        private string _internalVStartHookType;
        private string _internalVEndHookType;
        private string _internalVStartOrientation;
        private string _internalVEndOrientation;

        private string _externalHStartHookType;
        private string _externalHEndHookType;
        private string _externalHStartOrientation;
        private string _externalHEndOrientation;

        private string _internalHStartHookType;
        private string _internalHEndHookType;
        private string _internalHStartOrientation;
        private string _internalHEndOrientation;

        // Lengths & Slabs
        private double _externalVAnchorLengthFt;
        private double _externalVJointLengthFt;
        private double _internalVAnchorLengthFt;
        private double _internalVJointLengthFt;

        private double _externalHLeftAnchorLengthFt;
        private double _externalHRightAnchorLengthFt;
        private double _internalHLeftAnchorLengthFt;
        private double _internalHRightAnchorLengthFt;

        private double _exVBelowSlabFt;
        private double _exVTopSlabFt;
        private double _inVBelowSlabFt;
        private double _inVTopSlabFt;
        private double _exHLeftSlabFt;
        private double _exHRightSlabFt;
        private double _inHLeftSlabFt;
        private double _inHRightSlabFt;

        private RebarShape _rebarShape;

        // Foundation & Joints
        private double _foundationTHKFt;
        private double _lowestJointFt;
        private double _foundationTHKFtO;
        private double _slabTHKFt;

        public RebarSetBuilder(Document doc)
        {
            _doc = doc ?? throw new ArgumentNullException(nameof(doc));
        }

        public IRebarBuilder SetHost(Autodesk.Revit.DB.Wall hostElement)
        {
            _hostElement = hostElement ?? throw new ArgumentNullException(nameof(hostElement));
            return this;
        }

        public IRebarBuilder SetRebarDto(RebarDto rebarDto)
        {
            _rebarDto = rebarDto ?? throw new ArgumentNullException(nameof(rebarDto));
            return this;
        }

        public IRebarBuilder SetGeometry()
        {
            if (_hostElement == null) return this;

            // ၁။ Helper မှတစ်ဆင့် Wall Geometry အချက်အလက်များရယူခြင်း (Feet ဖြင့် ရရှိမည်)
            var (wallStart, wallEnd, wallDir, wallLength, wallHeight, wallThickness, baseOffset, topOffset) =
                RebarHostHelper.GetActualWallGeometry(_hostElement);

            _wallStartPoint = wallStart;
            _wallEndPoint = wallEnd;
            _wallDirection = wallDir;
            _wallLength = wallLength;
            _wallThickness = wallThickness;
            _wallHeight = wallHeight;
            _wallBaseOffset = baseOffset; // Feet

            // Top Offset ကို Feet အတိုင်းယူခြင်း
            _wallTopOffset = topOffset;

            // ၂။ Robust Face Detection (GeometryInstance ပါ ထည့်သွင်းစစ်ဆေးခြင်း)
            Options opt = new Options { ComputeReferences = true, DetailLevel = ViewDetailLevel.Fine };
            GeometryElement geoElem = _hostElement.get_Geometry(opt);

            foreach (GeometryObject obj in geoElem)
            {
                if (obj is Solid solid && solid.Volume > 0)
                {
                    ExtractFaces(solid);
                }
                else if (obj is GeometryInstance inst)
                {
                    // Instance Geometry ထဲမှ Solid ကို ထပ်မံရှာဖွေခြင်း
                    GeometryElement instElem = inst.GetInstanceGeometry();
                    foreach (GeometryObject instObj in instElem)
                    {
                        if (instObj is Solid instSolid && instSolid.Volume > 0)
                            ExtractFaces(instSolid);
                    }
                }
            }
            return this;
        }

        // Face များကို ခွဲခြားပေးသည့် Helper Method
        private void ExtractFaces(Solid solid)
        {
            foreach (Face face in solid.Faces)
            {
                if (face is PlanarFace pf)
                {
                    XYZ normal = pf.FaceNormal;

                    // DotProduct သုံး၍ မျက်နှာပြင် ဦးတည်ချက်ကို ပိုမိုတိကျစွာ စစ်ဆေးခြင်း
                    double dot = normal.DotProduct(_hostElement.Orientation);

                    if (dot > 0.90) // Exterior Face
                    {
                        _exteriorFace = face;
                        _exteriorFaceNormal = normal;
                    }
                    else if (dot < -0.90) // Interior Face
                    {
                        _interiorFace = face;
                        _interiorFaceNormal = normal;
                    }
                }
            }
        }

        public IRebarBuilder SetRebarType(string wallName, double internalVBarDia, double externalVBarDia, double internalHBarDia, double externalHBarDia, double uBarDiameter)
        {
            // 수직근 (Vertical Bars)
            _internalVBar = RebarTypeHelper.GetRebarType(_doc, internalVBarDia, $"{wallName}_수직근_D{internalVBarDia}");
            _externalVBar = RebarTypeHelper.GetRebarType(_doc, externalVBarDia, $"{wallName}_수직근_D{externalVBarDia}");

            // 수평근 (Horizontal Bars)
            _internalHBar = RebarTypeHelper.GetRebarType(_doc, internalHBarDia, $"{wallName}_수평근_D{internalHBarDia}");
            _externalHBar = RebarTypeHelper.GetRebarType(_doc, externalHBarDia, $"{wallName}_수평근_D{externalHBarDia}");

            // 수직근 이음 (Vertical Joints)
            _inVJointBar = RebarTypeHelper.GetRebarType(_doc, internalVBarDia, $"{wallName}_수직근_D{internalVBarDia}_이음");
            _exVJointBar = RebarTypeHelper.GetRebarType(_doc, externalVBarDia, $"{wallName}_수직근_D{externalVBarDia}_이음");

            // 수평근 이음 (Horizontal Joints)
            _inHJointBar = RebarTypeHelper.GetRebarType(_doc, internalHBarDia, $"{wallName}_수평근_D{internalHBarDia}_8m이음");
            _exHJointBar = RebarTypeHelper.GetRebarType(_doc, externalHBarDia, $"{wallName}_수평근_D{externalHBarDia}_8m이음");

            // U형바 (U-Bars)
            if (uBarDiameter > 0)
            {
                _uBar = RebarTypeHelper.GetRebarType(_doc, uBarDiameter, $"{wallName}_U형바_D{uBarDiameter}");
                _capTieBar = RebarTypeHelper.GetRebarType(_doc, 10, $"옹벽_폭고정근_D10");
            }

            //MT2
            _barType = RebarTypeHelper.GetRebarType(_doc, internalHBarDia, $"{wallName}_수평근_D{internalHBarDia}");

            return this;
        }

        public IRebarBuilder SetCover(double coverFt)
        {
            if (coverFt >= 0) _sideCover = coverFt;
            else throw new ArgumentException($"Cover {coverFt} must be >= 0.");
            return this;
        }

        public IRebarBuilder SetRebarShape()
        {
            _rebarShape = RebarShapeHelper.FindUBar(_doc);

            return this;
        }

        public IRebarBuilder SetSpacing(double internalVBarSpacing, double externalVBarSpacing, double internalHBarSpacing,
            double externalHBarSpacing, double uBarSpacing)
        {
            _internalVBarSpacing = internalVBarSpacing;
            _externalVBarSpacing = externalVBarSpacing;

            _internalHBarSpacing = internalHBarSpacing;
            _externalHBarSpacing = externalHBarSpacing;

            _uBarSpacing = uBarSpacing;

            return this;
        }

        public IRebarBuilder SetExternalVHooks(string startHookType, string endHookType, string startOrientation, string endOrientation)
        {
            _externalVStartHookType = startHookType;
            _externalVEndHookType = endHookType;
            _externalVStartOrientation = startOrientation;
            _externalVEndOrientation = endOrientation;
            return this;
        }

        public IRebarBuilder SetInternalVHooks(string startHookType, string endHookType, string startOrientation, string endOrientation)
        {
            _internalVStartHookType = startHookType;
            _internalVEndHookType = endHookType;
            _internalVStartOrientation = startOrientation;
            _internalVEndOrientation = endOrientation;
            return this;
        }

        public IRebarBuilder SetExternalHHooks(string startHookType, string endHookType, string startOrientation, string endOrientation)
        {
            _externalHStartHookType = startHookType;
            _externalHEndHookType = endHookType;
            _externalHStartOrientation = startOrientation;
            _externalHEndOrientation = endOrientation;
            return this;
        }

        public IRebarBuilder SetInternalHHooks(string startHookType, string endHookType, string startOrientation, string endOrientation)
        {
            _internalHStartHookType = startHookType;
            _internalHEndHookType = endHookType;
            _internalHStartOrientation = startOrientation;
            _internalHEndOrientation = endOrientation;
            return this;
        }

        public IRebarBuilder SetExternalVLengths(double anchorLengthFt, double jointLengthFt)
        {
            _externalVAnchorLengthFt = anchorLengthFt;
            _externalVJointLengthFt = jointLengthFt;
            return this;
        }

        public IRebarBuilder SetInternalVLengths(double anchorLengthFt, double jointLengthFt)
        {
            _internalVAnchorLengthFt = anchorLengthFt;
            _internalVJointLengthFt = jointLengthFt;
            return this;
        }

        public IRebarBuilder SetExternalHLengths(double leftAnchorLength, double rightAnchorLength)
        {
            _externalHLeftAnchorLengthFt = leftAnchorLength;
            _externalHRightAnchorLengthFt = rightAnchorLength;
            return this;
        }

        public IRebarBuilder SetInternalHLengths(double leftAnchorLength, double rightAnchorLength)
        {
            _internalHLeftAnchorLengthFt = leftAnchorLength;
            _internalHRightAnchorLengthFt = rightAnchorLength;
            return this;
        }

        public IRebarBuilder SetExternalVSlab(double belowFt, double topFt)
        {
            _exVBelowSlabFt = belowFt;
            _exVTopSlabFt = topFt;
            return this;
        }

        public IRebarBuilder SetInternalVSlab(double belowFt, double topFt)
        {
            _inVBelowSlabFt = Math.Max(0, belowFt);
            _inVTopSlabFt = Math.Max(0, topFt);
            return this;
        }

        public IRebarBuilder SetExternalHSlab(double leftFt, double rightFt)
        {
            _exHLeftSlabFt = Math.Max(0, leftFt);
            _exHRightSlabFt = Math.Max(0, rightFt);
            return this;
        }

        public IRebarBuilder SetInternalHSlab(double leftFt, double rightFt)
        {
            _inHLeftSlabFt = Math.Max(0, leftFt);
            _inHRightSlabFt = Math.Max(0, rightFt);
            return this;
        }

        public IRebarBuilder SetUBarSide(bool isUbar, UBarSide side)
        {
            _isUbar = isUbar;
            _uBarSide = side;
            return this;
        }

        public IRebarBuilder SetFoundationThickness(double foundationTHKFt)
        {
            _foundationTHKFt = Math.Max(0, foundationTHKFt);
            return this;
        }

        public IRebarBuilder SetLowestJoint(double lowestJointFt)
        {
            _lowestJointFt = Math.Max(0, lowestJointFt);
            return this;
        }

        public IRebarBuilder SetSlabTHK(double slabTHKFt)
        {
            _slabTHKFt = Math.Max(0, slabTHKFt);
            _exVTopSlabFt = _slabTHKFt;
            _inVTopSlabFt = _slabTHKFt;
            return this;
        }

        public IRebarBuilder SetMiddleFloorLengths(double internalJointLength, double externalJointLength)
        {
            _internalVAnchorLengthFt = 0;
            _externalVAnchorLengthFt = 0;

            _internalVJointLengthFt = internalJointLength;
            _externalVJointLengthFt = externalJointLength;

            return this;
        }

        public IRebarBuilder SetFoundationTHK(double foundationTHKFtO)
        {
            _foundationTHKFtO = Math.Max(0, foundationTHKFtO);
            return this;
        }

        public RebarSetsResultDto Build()
        {
            if (_hostElement == null)
                throw new Exception("Host element not set.");

            // ⭐ Single Rebar Case
            if (_rebarDto != null && _rebarDto.IsSingle)
            {
                return BuildSingleExternalRebar();
            }

            if (_internalVBar == null || _externalVBar == null ||
                _internalHBar == null || _externalHBar == null)
                throw new Exception("Rebar types not set.");

            if (_sideCover < 0)
                throw new Exception("Cover not set.");

            if (_internalVBarSpacing <= 0 || _externalVBarSpacing <= 0 ||
                _internalHBarSpacing <= 0 || _externalHBarSpacing <= 0)
                throw new Exception("Rebar spacing not set.");

            if (_exteriorFace == null || _interiorFace == null || _wallDirection == null)
                throw new Exception("Wall geometry faces or direction not resolved. Check offset propagation.");

            // ၁။ Wall Length ကို mm ဖြင့် စစ်ဆေးရန် (680 mm Condition အတွက်)
            double wallLengthMm = UnitUtils.ConvertFromInternalUnits(_wallLength, UnitTypeId.Millimeters);
            //MessageBox.Show("wall length=" + wallLengthMm);

            // ⭐ Single Rebar Case
            if (_rebarDto != null && _rebarDto.IsSingle)
            {
                // External bars only
                var externalVBarSetSingle = CreateExternalVerticalRebar();
                var externalHBarSetSingle = CreateExternalHorizontalRebar();

                // Internal bars skipped
                return new RebarSetsResultDto(externalVBarSetSingle, null, externalHBarSetSingle, null, null, null);
            }

            // ၃။ Vertical Bars များ ဆွဲခြင်း 
            var externalVBarSet = CreateExternalVerticalRebar();
            var internalVBarSet = CreateInternalVerticalRebar();
            // ⭐ CapTies များကို List အနေဖြင့် လက်ခံယူပါ
            List<Autodesk.Revit.DB.Structure.Rebar> capTies = CreateMultipleVerticalCapTie();

            Autodesk.Revit.DB.Structure.Rebar externalHBarSet = null;
            Autodesk.Revit.DB.Structure.Rebar internalHBarSet = null;
            Autodesk.Revit.DB.Structure.Rebar leftUBarSet = null;
            Autodesk.Revit.DB.Structure.Rebar rightUBarSet = null;

            if (wallLengthMm < 680)
            {
                // ⭐ အစားထိုး Logic: Internal Horizontal နဲ့ U-Bar အစား M_T2 ကို တစ်ခါတည်းဆွဲသည်
                // M_T2 သည် တစ်ချောင်းတည်းဖြင့် Internal မျက်နှာပြင်ရော Side နှစ်ဖက်လုံးကိုပါ လွှမ်းခြုံသောကြောင့် ဖြစ်သည်
                internalHBarSet = CreateMT2TieRebarManual();
            }
            else
            {
                // ပုံမှန် Logic: Horizontal Rebar ကို အရင်ဆွဲသည်
                externalHBarSet = CreateExternalHorizontalRebar();
                internalHBarSet = CreateInternalHorizontalRebar();

                // U-Bar ဆွဲရန် ရှိ/မရှိ စစ်ဆေးခြင်း
                if (_isUbar)
                {
                    switch (_uBarSide)
                    {
                        case UBarSide.Left:
                            leftUBarSet = CreateLeftUBar();
                            break;
                        case UBarSide.Right:
                            rightUBarSet = CreateRightUBar();
                            break;
                        case UBarSide.Both:
                            leftUBarSet = CreateLeftUBar();
                            rightUBarSet = CreateRightUBar();
                            break;
                        case UBarSide.None:
                            break;
                    }
                }
            }

            return new RebarSetsResultDto(externalVBarSet, internalVBarSet, externalHBarSet, internalHBarSet, rightUBarSet, leftUBarSet, capTies);
        }

        // Wall Length 680mm အောက်တွင် Internal Horizontal နှင့် U-Bar အစားထိုးရန် M_T2 Shape ဆွဲခြင်း
        private Autodesk.Revit.DB.Structure.Rebar CreateMT2TieRebarManual()
        {
            double barRadius = _barType.BarNominalDiameter / 2.0;
            double offsetDist = _sideCover + barRadius;

            // ၁။ Intersect ဖြစ်နေသော တဖက် Wall နှစ်ခု၏ Extension Length (သို့မဟုတ် Thickness) များကို ယူခြင်း
            // GetCornerExtension သည် ဆုံနေသော Wall ၏ thickness နှင့် cover ကို တွက်ချက်ပေးသည်
            double autoStartExt = Math.Max(0, GetCornerExtension(_hostElement, 0));
            double autoEndExt = Math.Max(0, GetCornerExtension(_hostElement, 1));

            // ၂။ Wall ၏ မျက်နှာပြင်များပေါ်မူတည်၍ အခြေခံ Point များတွက်ချက်ခြင်း
            XYZ extSurf = GetProjectedPointOnFace(_exteriorFace, _wallStartPoint);
            XYZ intSurf = GetProjectedPointOnFace(_interiorFace, _wallStartPoint);
            double z = extSurf.Z + _wallBaseOffset + _sideCover + barRadius;

            // Start Point ကို Start Extension (autoStartExt) ရှိလျှင် ထိုဘက်သို့ အပြင်ဘက်သို့ တိုးထုတ်မည်
            XYZ startBasePt = _wallStartPoint - (_wallDirection * autoStartExt);

            // Cover နှင့် Wall Thickness Extension အပါအဝင် သုံးနိုင်သော Length စုစုပေါင်း
            double actualStartOffset = (autoStartExt > 0) ? 0 : offsetDist;
            double actualEndOffset = (autoEndExt > 0) ? 0 : offsetDist;
            // Usable Length ထဲသို့ Wall ၏ မူလအလျား (_wallLength) အပြင် ဘယ်ညာ ဆုံနေသော Wall နှစ်ခု၏ Extension အလျားများ (autoStartExt + autoEndExt) ကိုပါ ပေါင်းထည့်ပေးခြင်း
            double wallUsableLen = (_wallLength + autoStartExt + autoEndExt) - (actualStartOffset + actualEndOffset);

            // အခြေခံ ထောင့် Point ၄ ခု (Corners) တွက်ချက်ခြင်း
            XYZ p1 = GetProjectedPointOnFace(_exteriorFace, startBasePt);
            XYZ p2 = GetProjectedPointOnFace(_interiorFace, startBasePt);

            p1 = new XYZ(p1.X, p1.Y, z) + (_exteriorFaceNormal.Negate() * offsetDist) + (_wallDirection * actualStartOffset); // Top-Left
            p2 = new XYZ(p2.X, p2.Y, z) + (_interiorFaceNormal.Negate() * offsetDist) + (_wallDirection * actualStartOffset); // Bottom-Left

            // တွက်ထုတ်ထားသော wallUsableLen ဖြင့် ညာဘက်ထောင့် Point များကို ချဲ့ထွင်ခြင်း
            XYZ p3 = p2 + (_wallDirection * wallUsableLen); // Bottom-Right
            XYZ p4 = p1 + (_wallDirection * wallUsableLen); // Top-Right

            // ၃။ Overlap (A နှင့် G) အတွက် Point အသစ်များသတ်မှတ်ခြင်း (ဥပမာ - 155mm)
            double hookLen = 155.0 / 304.8; // mm to feet

            // A ကို E ပေါ်တွင် ထပ်နေစေရန် သို့မဟုတ် သက်ဆိုင်ရာနေရာတွင် Overlap ဖြစ်စေရန် direction ကို ညှိခြင်း
            // ဤနေရာတွင် p2 မှ p1 သို့သွားသော လမ်းကြောင်းပေါ်တွင် Overlap ဖြစ်စေရန် hookLen ကို သုံးထားသည်
            XYZ pA_start = p2 + (p1 - p2).Normalize() * hookLen; // Segment A အတွက် အစမှတ် (Left Side ပေါ်တွင်ရှိသည်)
            XYZ pG_end = p2 + (p3 - p2).Normalize() * hookLen;   // Segment G အတွက် အဆုံးမှတ် (Bottom Side ပေါ်တွင် Overlap ဖြစ်ရန်)

            // ၄။ Segment ၆ ခု (A, B, C, D, E, G) ကို တစ်ဆက်တည်း ဆွဲခြင်း
            // လမ်းကြောင်း: pA_start -> p2 -> p3 -> p4 -> p1 -> p2 -> pG_end
            List<Curve> curves = new List<Curve>();
            curves.Add(Line.CreateBound(pA_start, p2)); // A: Overlap on E
            curves.Add(Line.CreateBound(p2, p3));       // B: Bottom Side
            curves.Add(Line.CreateBound(p3, p4));       // C: Right Side
            curves.Add(Line.CreateBound(p4, p1));       // D: Top Side
            curves.Add(Line.CreateBound(p1, p2));       // E: Left Side
            curves.Add(Line.CreateBound(p2, pG_end));   // G: Overlap on B

            // ၅။ Normal Vector ကို တိကျစွာတွက်ချက်ခြင်း (Internal Error မတက်စေရန်)
            XYZ normal = _wallDirection.CrossProduct(_exteriorFaceNormal).Normalize();

            // ၆။ Rebar ဖန်တီးခြင်း (Standard Style ကိုသုံးပါ၊ Hook parameter များ မလိုအပ်တော့ပါ)
            var bar = Autodesk.Revit.DB.Structure.Rebar.CreateFromCurves(
                _doc,
                RebarStyle.Standard,
                _barType,
                null, null,
                _hostElement, normal, curves,
                RebarHookOrientation.Right, RebarHookOrientation.Right,
                true, true);

            if (bar != null)
            {
                double distributionHeight = _wallHeight - (2.0 * _sideCover);
                bar.GetShapeDrivenAccessor().SetLayoutAsMaximumSpacing(
                    _internalHBarSpacing, distributionHeight, true, true, true);
            }

            return bar;
        }


        // Wall Join ကို စစ်ဆေးပြီး Extension Length တွက်မည့် Helper Method
        private double GetCornerExtension(Wall wall, int endIndicator) // 0 for Start, 1 for End
        {
            LocationCurve locCurve = wall.Location as LocationCurve;
            if (locCurve == null) return 0;

            // 1 Wall ရဲ့ အစ (သို့) အဆုံး Point ကို ယူပါ
            XYZ endPoint = locCurve.Curve.GetEndPoint(endIndicator);

            XYZ mainDir = (locCurve.Curve as Line)?.Direction;

            // 2 အဲဒီ Point နားမှာ ရှိတဲ့ တခြား Wall တွေကို ရှာပါ (FilteredElementCollector သုံးပြီး)
            // လက်ရှိ Wall ကိုတော့ ဖယ်ထားရပါမယ် (Excluding)
            var collector = new FilteredElementCollector(_doc)
                .OfClass(typeof(Wall))
                .Excluding(new List<ElementId> { wall.Id });

            double bestExtension = 0;
            double minDistance = double.MaxValue; // အနီးဆုံး Wall ကို ရွေးချယ်ရန်

            foreach (Wall joinedWall in collector.Cast<Wall>())
            {
                LocationCurve otherLoc = joinedWall.Location as LocationCurve;
                if (otherLoc == null) continue;

                // 3 Parallel (အပြိုင်) ဖြစ်နေသော Wall များကို ကျော်မည်
                XYZ otherDir = (otherLoc.Curve as Line)?.Direction;
                if (mainDir != null && otherDir != null)
                {
                    if (Math.Abs(mainDir.DotProduct(otherDir)) > 0.98) continue;
                }

                double joinedWallThickness = joinedWall.WallType.Width;
                double dist = otherLoc.Curve.Distance(endPoint);

                // 4 အကွာအဝေး အတိအကျ စစ်ဆေးခြင်း (Vertical Rebars များခြင်းကို ဖြေရှင်းရန်)
                // Allow Join ဖြစ်လျှင် endpoint သည် Center ထိရောက်နေသဖြင့် dist သည် 0 နီးပါးဖြစ်သည်။
                // Disallow Join ဖြစ်လျှင် Face တွင် ကပ်နေသဖြင့် dist သည် Target Wall အထူ၏ တစ်ဝက်ခန့် ဖြစ်သည်။
                double expectedDisallowDist = joinedWallThickness / 2.0;

                bool isAllowJoin = dist < 0.05; // 0.05 ft (~15mm) အတွင်း
                bool isDisallowJoin = Math.Abs(dist - expectedDisallowDist) < 0.05; // Face ပေါ်တွင် အတိအကျ ကပ်နေလျှင်

                if ((isAllowJoin || isDisallowJoin) && dist < minDistance)
                {
                    minDistance = dist;

                    // 5. Wall အထူအပြည့် ဖြတ်သန်းရန် (Extension အရှည်ကို ဖြေရှင်းရန်)
                    bool isSingleBar = (_rebarDto != null && _rebarDto.IsSingle);

                    if (isSingleBar)
                    {
                        // 💡 Single Bar ဖြစ်နေပါက Join အခြေအနေမည်သို့ပင်ဖြစ်စေ Wall အထူအပြည့် (Thickness အပြည့်) ထိ ဆွဲဆန့်မည်
                        bestExtension = joinedWallThickness;
                    }
                    else if (isDisallowJoin && !isAllowJoin)
                    {
                        // Disallow Join: ဒု Wall သည် Face တွင် ရပ်နေသဖြင့် ပ Wall ၏ အထူအပြည့်မှ Cover ကို နှုတ်ပါမည်။
                        bestExtension = joinedWallThickness - _sideCover;
                    }
                    else
                    {
                        // Allow Join: ဒု Wall ၏ Endpoint သည် Center တွင် ရောက်နေပြီးဖြစ်သဖြင့် အထူတစ်ဝက်မှ Cover နှုတ်ပါမည်။
                        bestExtension = (joinedWallThickness / 2.0) - _sideCover;
                    }
                }
            }

            return Math.Max(0, bestExtension);
        }

        // ==========================================
        // EXTERNAL VERTICAL
        // ==========================================
        private Autodesk.Revit.DB.Structure.Rebar CreateExternalVerticalRebar()
        {
            // ၁။ Parameter များ သတ်မှတ်ခြင်း
            double maxTotalFt = UnitUtils.ConvertToInternalUnits(8000, UnitTypeId.Millimeters);
            double spliceGapFt = _externalVJointLengthFt;
            double vBarRadius = _externalVBar.BarNominalDiameter / 2.0;
            double hBarDia = _externalHBar.BarNominalDiameter;

            // ၂။ Layering နှင့် Positioning (Vertical ကို Horizontal ရဲ့ အတွင်းဘက်သို့ ပို့ခြင်း)
            double offsetFromFace = _sideCover + hBarDia + vBarRadius;
            double startEndOffset = _sideCover + vBarRadius;

            // Exterior Face ပေါ်ရှိ အခြေခံ Point ကို ယူခြင်း
            XYZ extSurf = GetProjectedPointOnFace(_exteriorFace, _wallStartPoint);

            // Face Normal အတိုင်း အတွင်းသို့ ရွှေ့ပြီး Wall Base Offset ကို ထည့်တွက်ခြင်း
            XYZ baseInsidePlane = extSurf + (_exteriorFaceNormal.Negate() * offsetFromFace);
            XYZ baseInside = new XYZ(baseInsidePlane.X, baseInsidePlane.Y, extSurf.Z + _wallBaseOffset);

            // ၃။ Layout အတွက် Start Point နှင့် Length ကို တွက်ချက်ခြင်း (Radius အပြင်ထွက်ခြင်းကို ဖြေရှင်းရန်)
            XYZ distributionStartPoint = baseInside + (_wallDirection * startEndOffset);
            double adjustedLayoutLength = _wallLength - (2 * startEndOffset);

            // Layout Length သည် 0 ထက် ငယ်မသွားစေရန် စစ်ဆေးခြင်း
            if (adjustedLayoutLength < 0.001) adjustedLayoutLength = 0;

            double usableHeight = _wallHeight;
            var startOrient = _externalVStartOrientation == "Right" ? RebarHookOrientation.Right : RebarHookOrientation.Left;
            var endOrient = _externalVEndOrientation == "Right" ? RebarHookOrientation.Right : RebarHookOrientation.Left;

            double bottomTail = 0;
            double topTail = 0;
            RebarHookType startHook = null;
            RebarHookType endHook = null;

            double totalBars = (_rebarDto != null && _rebarDto.FN > 0) ? _rebarDto.FN : 0;

            // ၄။ Floor-specific Logic
            if (_rebarDto.IsLowestFloor)
            {
                // Segment 1: Bottom hook-only bar
                XYZ hookStart = distributionStartPoint - XYZ.BasisZ * _foundationTHKFt;
                XYZ hookEnd = distributionStartPoint + XYZ.BasisZ * _externalVJointLengthFt;
                Line hookLine = Line.CreateBound(hookStart, hookEnd);

                var hookBar = Autodesk.Revit.DB.Structure.Rebar.CreateFromCurves(
                    _doc, RebarStyle.Standard, _exVJointBar,
                    ResolveHook(_externalVStartHookType), null,
                    _hostElement, _wallDirection, new List<Curve> { hookLine },
                    startOrient, endOrient, true, true);

                ApplyBarLayout(hookBar, adjustedLayoutLength, totalBars, _externalVBarSpacing, true); // (External အတွက် isCeiling = true)

                // Segment 2: Wall vertical bar
                XYZ wallStart = distributionStartPoint;
                XYZ wallEnd = distributionStartPoint + XYZ.BasisZ * (usableHeight + _externalVJointLengthFt + _slabTHKFt);
                Line wallLine = Line.CreateBound(wallStart, wallEnd);

                var wallBar = Autodesk.Revit.DB.Structure.Rebar.CreateFromCurves(
                    _doc, RebarStyle.Standard, _externalVBar,
                    null, null,
                    _hostElement, _wallDirection, new List<Curve> { wallLine },
                    startOrient, endOrient, true, true);

                ApplyBarLayout(wallBar, adjustedLayoutLength, totalBars, _externalVBarSpacing, true);

                return hookBar;
            }
            else if (_rebarDto.IsMiddleFloor)
            {
                bottomTail = 0; topTail = _externalVJointLengthFt + _slabTHKFt;
            }
            else if (_rebarDto.IsTopFloor)
            {
                bottomTail = 0; topTail = _slabTHKFt;
                endHook = _externalVEndHookType == "None" ? null : ResolveHook(_externalVEndHookType);
            }
            else if (_rebarDto.IsOnlyFloor)
            {
                // Foundation part
                XYZ hookStart = distributionStartPoint - XYZ.BasisZ * _foundationTHKFtO;
                XYZ hookEnd = distributionStartPoint + XYZ.BasisZ * _externalVAnchorLengthFt;
                Line hookLine = Line.CreateBound(hookStart, hookEnd);

                var hookBar = Autodesk.Revit.DB.Structure.Rebar.CreateFromCurves(
                    _doc, RebarStyle.Standard, _exVJointBar,
                    ResolveHook(_externalVStartHookType), null,
                    _hostElement, _wallDirection, new List<Curve> { hookLine },
                    startOrient, endOrient, true, true);

                ApplyBarLayout(hookBar, adjustedLayoutLength, totalBars, _externalVBarSpacing, true);

                // Wall part
                topTail = _externalVJointLengthFt + _slabTHKFt;
                XYZ wallStart = distributionStartPoint;
                XYZ wallEnd = distributionStartPoint + XYZ.BasisZ * (usableHeight + topTail);
                Line wallLine = Line.CreateBound(wallStart, wallEnd);

                var wallBar = Autodesk.Revit.DB.Structure.Rebar.CreateFromCurves(
                    _doc, RebarStyle.Standard, _externalVBar,
                    null, ResolveHook(_externalVEndHookType),
                    _hostElement, _wallDirection, new List<Curve> { wallLine },
                    startOrient, endOrient, true, true);

                ApplyBarLayout(wallBar, adjustedLayoutLength, totalBars, _externalVBarSpacing, true);

                return hookBar;
            }

            // ၅။ 8m Split Logic အတွက် loop အပိုင်း
            Autodesk.Revit.DB.Structure.Rebar firstBar = null;

            if (usableHeight + bottomTail + topTail <= maxTotalFt)
            {
                XYZ bottomPt = distributionStartPoint - XYZ.BasisZ * bottomTail;
                XYZ topPt = distributionStartPoint + XYZ.BasisZ * (usableHeight + topTail);
                Line barLine = Line.CreateBound(bottomPt, topPt);

                firstBar = Autodesk.Revit.DB.Structure.Rebar.CreateFromCurves(
                    _doc, RebarStyle.Standard, _externalVBar, startHook, endHook,
                    _hostElement, _wallDirection, new List<Curve> { barLine },
                    startOrient, endOrient, true, true);

                ApplyBarLayout(firstBar, adjustedLayoutLength, totalBars, _externalVBarSpacing, true);

                return firstBar;
            }

            double offsetZ = 0.0;
            double remaining = usableHeight;
            int index = 0;

            while (remaining > 0)
            {
                bool isFirst = (index == 0);
                double insideLenFirst = Math.Max(0, maxTotalFt - bottomTail);
                double insideLenMiddle = maxTotalFt;
                double insideLenLast = Math.Max(0, maxTotalFt - topTail);

                bool isLast = false;
                double segmentLen;

                if (isFirst) segmentLen = insideLenFirst;
                else
                {
                    if (remaining <= insideLenLast) { isLast = true; segmentLen = insideLenLast; }
                    else segmentLen = insideLenMiddle;
                }
                segmentLen = Math.Min(segmentLen, remaining);

                XYZ segBase = distributionStartPoint + XYZ.BasisZ * offsetZ;
                XYZ segTop = segBase + XYZ.BasisZ * segmentLen;

                if (isFirst) segBase -= XYZ.BasisZ * bottomTail;
                if (isLast) segTop += XYZ.BasisZ * topTail;

                Line segLine = Line.CreateBound(segBase, segTop);
                var segBar = Autodesk.Revit.DB.Structure.Rebar.CreateFromCurves(
                    _doc, RebarStyle.Standard, _externalVBar,
                    isFirst ? startHook : null, isLast ? endHook : null,
                    _hostElement, _wallDirection, new List<Curve> { segLine },
                    startOrient, endOrient, true, true);

                ApplyBarLayout(segBar, adjustedLayoutLength, totalBars, _externalVBarSpacing, true);

                if (firstBar == null) firstBar = segBar;

                offsetZ += segmentLen;
                remaining -= segmentLen;

                if (!isLast && remaining > 0)
                {
                    double gapLen = Math.Min(spliceGapFt, remaining);
                    XYZ gapStart = distributionStartPoint + XYZ.BasisZ * offsetZ;
                    XYZ gapEnd = gapStart + XYZ.BasisZ * gapLen;
                    Line gapLine = Line.CreateBound(gapStart, gapEnd);

                    var gapBar = Autodesk.Revit.DB.Structure.Rebar.CreateFromCurves(
                        _doc, RebarStyle.Standard, _exVJointBar, null, null,
                        _hostElement, _wallDirection, new List<Curve> { gapLine },
                        startOrient, endOrient, true, true);

                    ApplyBarLayout(gapBar, adjustedLayoutLength, totalBars, _externalVBarSpacing, true);

                    offsetZ += gapLen;
                    remaining -= gapLen;
                }
                index++;
            }
            return firstBar;
        }

        // ==========================================
        // INTERNAL VERTICAL
        // ==========================================
        private Autodesk.Revit.DB.Structure.Rebar CreateInternalVerticalRebar()
        {
            // ၁။ Parameter များ သတ်မှတ်ခြင်း
            double maxTotalFt = UnitUtils.ConvertToInternalUnits(8000, UnitTypeId.Millimeters);
            double spliceGapFt = _internalVJointLengthFt;
            double vBarRadius = _internalVBar.BarNominalDiameter / 2.0;
            double hBarDia = _internalHBar.BarNominalDiameter; // Internal Horizontal Bar Diameter

            // ၂။ Layering နှင့် Positioning (Vertical ကို Horizontal ရဲ့ အတွင်းဘက်သို့ ပို့ခြင်း)
            // Side Cover + Horizontal Bar အထူ + Vertical Bar Radius
            double offsetFromFace = _sideCover + hBarDia + vBarRadius;

            // Wall အစွန်း (Corners) မှ အတွင်းသို့ ဝင်မည့် Offset (Radius အပြင်ထွက်ခြင်းကို ကာကွယ်ရန်)
            double startEndOffset = _sideCover + vBarRadius;

            // Interior Face ပေါ်ရှိ အခြေခံ Point ကို ယူခြင်း
            XYZ intSurf = GetProjectedPointOnFace(_interiorFace, _wallStartPoint);

            // Face Normal အတိုင်း အတွင်းသို့ ရွှေ့ပြီး Wall Base Offset ကို Z-axis တွင် ထည့်တွက်ခြင်း
            XYZ baseInsidePlane = intSurf + (_interiorFaceNormal.Negate() * offsetFromFace);
            XYZ baseInside = new XYZ(baseInsidePlane.X, baseInsidePlane.Y, intSurf.Z + _wallBaseOffset);

            // ၃။ Layout အတွက် Start Point နှင့် Length ကို တွက်ချက်ခြင်း
            XYZ distributionStartPoint = baseInside + (_wallDirection * startEndOffset);
            double adjustedLayoutLength = _wallLength - (2 * startEndOffset);
            if (adjustedLayoutLength < 0.001) adjustedLayoutLength = 0;

            double usableHeight = _wallHeight;
            var startOrient = _internalVStartOrientation == "Right" ? RebarHookOrientation.Right : RebarHookOrientation.Left;
            var endOrient = _internalVEndOrientation == "Right" ? RebarHookOrientation.Right : RebarHookOrientation.Left;

            double bottomTail = 0;
            double topTail = 0;
            RebarHookType startHook = null;
            RebarHookType endHook = null;

            double totalBars = (_rebarDto != null && _rebarDto.FN > 0) ? _rebarDto.FN : 0;

            // ၄။ Floor-specific Logic
            if (_rebarDto.IsLowestFloor)
            {
                // Segment 1: Bottom hook-only bar
                XYZ hookStart = distributionStartPoint - XYZ.BasisZ * _foundationTHKFt;
                XYZ hookEnd = distributionStartPoint + XYZ.BasisZ * _internalVJointLengthFt;
                Line hookLine = Line.CreateBound(hookStart, hookEnd);

                var hookBar = Autodesk.Revit.DB.Structure.Rebar.CreateFromCurves(
                    _doc, RebarStyle.Standard, _inVJointBar,
                    ResolveHook(_internalVStartHookType), null,
                    _hostElement, _wallDirection, new List<Curve> { hookLine },
                    startOrient, startOrient, true, true);

                ApplyBarLayout(hookBar, adjustedLayoutLength, totalBars, _internalVBarSpacing, false);  // Internal အတွက် isCeiling = false (external နဲ့ ပေါင်းလိုက်ရင် စုစုပေါင်း FN အတိအကျရရန်)

                // Segment 2: Wall vertical bar
                XYZ wallStart = distributionStartPoint;
                XYZ wallEnd = distributionStartPoint + XYZ.BasisZ * (usableHeight + _internalVJointLengthFt + _slabTHKFt);
                Line wallLine = Line.CreateBound(wallStart, wallEnd);

                var wallBar = Autodesk.Revit.DB.Structure.Rebar.CreateFromCurves(
                    _doc, RebarStyle.Standard, _internalVBar,
                    null, null,
                    _hostElement, _wallDirection, new List<Curve> { wallLine },
                    startOrient, endOrient, true, true);

                ApplyBarLayout(wallBar, adjustedLayoutLength, totalBars, _internalVBarSpacing, false);

                return hookBar;
            }
            else if (_rebarDto.IsMiddleFloor)
            {
                bottomTail = 0; topTail = _internalVJointLengthFt + _slabTHKFt;
            }
            else if (_rebarDto.IsTopFloor)
            {
                bottomTail = 0; topTail = _slabTHKFt;
                endHook = _internalVEndHookType == "None" ? null : ResolveHook(_internalVEndHookType);
                startHook = null;
            }
            else if (_rebarDto.IsOnlyFloor)
            {
                // Foundation part
                XYZ hookStart = distributionStartPoint - XYZ.BasisZ * _foundationTHKFtO;
                XYZ hookEnd = distributionStartPoint + XYZ.BasisZ * _internalVAnchorLengthFt;
                Line hookLine = Line.CreateBound(hookStart, hookEnd);

                var hookBar = Autodesk.Revit.DB.Structure.Rebar.CreateFromCurves(
                    _doc, RebarStyle.Standard, _inVJointBar,
                    ResolveHook(_internalVStartHookType), null,
                    _hostElement, _wallDirection, new List<Curve> { hookLine },
                    startOrient, endOrient, true, true);

                ApplyBarLayout(hookBar, adjustedLayoutLength, totalBars, _internalVBarSpacing, false);

                // Wall part
                topTail = _internalVJointLengthFt + _slabTHKFt;
                XYZ wallStart = distributionStartPoint;
                XYZ wallEnd = distributionStartPoint + XYZ.BasisZ * (usableHeight + topTail);
                Line wallLine = Line.CreateBound(wallStart, wallEnd);

                var wallBar = Autodesk.Revit.DB.Structure.Rebar.CreateFromCurves(
                    _doc, RebarStyle.Standard, _internalVBar,
                    null, ResolveHook(_internalVEndHookType),
                    _hostElement, _wallDirection, new List<Curve> { wallLine },
                    startOrient, endOrient, true, true);

                ApplyBarLayout(wallBar, adjustedLayoutLength, totalBars, _internalVBarSpacing, false);

                return hookBar;
            }

            // ၅။ 8m Split Logic
            Autodesk.Revit.DB.Structure.Rebar firstBar = null;

            if (usableHeight + bottomTail + topTail <= maxTotalFt)
            {
                XYZ bottomPt = distributionStartPoint - XYZ.BasisZ * bottomTail;
                XYZ topPt = distributionStartPoint + XYZ.BasisZ * (usableHeight + topTail);
                Line barLine = Line.CreateBound(bottomPt, topPt);

                firstBar = Autodesk.Revit.DB.Structure.Rebar.CreateFromCurves(
                    _doc, RebarStyle.Standard, _internalVBar, startHook, endHook,
                    _hostElement, _wallDirection, new List<Curve> { barLine },
                    startOrient, endOrient, true, true);

                ApplyBarLayout(firstBar, adjustedLayoutLength, totalBars, _internalVBarSpacing, false);

                return firstBar;
            }

            double offsetZ = 0.0;
            double remaining = usableHeight;
            int index = 0;

            while (remaining > 0)
            {
                bool isFirst = (index == 0);
                double insideLenFirst = Math.Max(0, maxTotalFt - bottomTail);
                double insideLenMiddle = maxTotalFt;
                double insideLenLast = Math.Max(0, maxTotalFt - topTail);
                bool isLast = false;
                double segmentLen;

                if (isFirst) segmentLen = insideLenFirst;
                else
                {
                    if (remaining <= insideLenLast) { isLast = true; segmentLen = insideLenLast; }
                    else segmentLen = insideLenMiddle;
                }
                segmentLen = Math.Min(segmentLen, remaining);

                XYZ segBase = distributionStartPoint + XYZ.BasisZ * offsetZ;
                XYZ segTop = segBase + XYZ.BasisZ * segmentLen;

                if (isFirst) segBase -= XYZ.BasisZ * bottomTail;
                if (isLast) segTop += XYZ.BasisZ * topTail;

                Line segLine = Line.CreateBound(segBase, segTop);
                var segBar = Autodesk.Revit.DB.Structure.Rebar.CreateFromCurves(
                    _doc, RebarStyle.Standard, _internalVBar,
                    isFirst ? startHook : null, isLast ? endHook : null,
                    _hostElement, _wallDirection, new List<Curve> { segLine },
                    startOrient, endOrient, true, true);

                ApplyBarLayout(segBar, adjustedLayoutLength, totalBars, _internalVBarSpacing, false);

                if (firstBar == null) firstBar = segBar;
                offsetZ += segmentLen;
                remaining -= segmentLen;

                if (!isLast && remaining > 0)
                {
                    double gapLen = Math.Min(spliceGapFt, remaining);
                    XYZ gapStart = distributionStartPoint + XYZ.BasisZ * offsetZ;
                    XYZ gapEnd = gapStart + XYZ.BasisZ * gapLen;
                    Line gapLine = Line.CreateBound(gapStart, gapEnd);

                    var gapBar = Autodesk.Revit.DB.Structure.Rebar.CreateFromCurves(
                        _doc, RebarStyle.Standard, _inVJointBar, null, null,
                        _hostElement, _wallDirection, new List<Curve> { gapLine },
                       startOrient, endOrient, true, true);

                    ApplyBarLayout(gapBar, adjustedLayoutLength, totalBars, _internalVBarSpacing, false);

                    offsetZ += gapLen;
                    remaining -= gapLen;
                }
                index++;
            }
            return firstBar;
        }

        // ==========================================
        // EXTERNAL HORIZONTAL
        // ==========================================
        private Autodesk.Revit.DB.Structure.Rebar CreateExternalHorizontalRebar()
        {
            // 1. Spacing/Joint Length သတ်မှတ်ခြင်း
            double spacingFt = _rebarDto.ExHLeftJointLength;
            if (spacingFt < 0.001) spacingFt = UnitUtils.ConvertToInternalUnits(1, UnitTypeId.Millimeters);

            // 2. Start Point တွက်ချက်ခြင်း
            XYZ extSurf = GetProjectedPointOnFace(_exteriorFace, _wallStartPoint);
            double barRadius = _externalHBar.BarNominalDiameter / 2.0;
            double startZ = extSurf.Z + _wallBaseOffset + _sideCover + barRadius;

            XYZ horizontalBaseXY = extSurf + (_exteriorFaceNormal.Negate() * (_sideCover + barRadius));
            XYZ exStart = new XYZ(horizontalBaseXY.X, horizontalBaseXY.Y, startZ);
            // Start point ကို side cover နေရာကနေ စပါ
            //exStart = exStart + (_wallDirection * _sideCover);

            // 3. Parameters
            //double usableLength = _wallLength - (2 * _sideCover);
            double usableLength = _wallLength;
            var startHook = _externalHStartHookType == "None" ? null : ResolveHook(_externalHStartHookType);
            var endHook = _externalHEndHookType == "None" ? null : ResolveHook(_externalHEndHookType);
            var startOrient = _externalHStartOrientation == "Right" ? RebarHookOrientation.Right : RebarHookOrientation.Left;
            var endOrient = _externalHEndOrientation == "Right" ? RebarHookOrientation.Right : RebarHookOrientation.Left;

            // ⭐ အလိုအလျောက် Extension တွက်ချက်ခြင်း
            double autoLeftTail = Math.Max(0, GetCornerExtension(_hostElement, 0));
            double autoRightTail = Math.Max(0, GetCornerExtension(_hostElement, 1));

            // User ပေးထားတဲ့ Anchor နဲ့ အလိုအလျောက်တွက်ထားတာထဲက ပိုကြီးတာကို ယူနိုင်ပါတယ်
            double leftTail = _externalHLeftAnchorLengthFt + autoLeftTail;
            double rightTail = _externalHRightAnchorLengthFt + autoRightTail;
            double height = _wallHeight - (2 * _sideCover);

            // ၈ မီတာ ကန့်သတ်ချက် (Internal Units/Feet)
            double maxSegmentFt = UnitUtils.ConvertToInternalUnits(8000, UnitTypeId.Millimeters);

            Autodesk.Revit.DB.Structure.Rebar firstBar = null;
            double currentOffset = 0.0;

            while (currentOffset < usableLength)
            {
                bool isFirst = (currentOffset == 0);
                double remainingWallLength = usableLength - currentOffset;

                // ⭐ အဓိကပြင်ဆင်ချက်- သံချောင်းအရှည်တွက်ချက်ခြင်း
                // Anchor length ပါဝင်လာပါက ၈ မီတာထက် မကျော်စေရန် maxSegmentFt ထဲမှ Anchor ကို နှုတ်၍ wall length ကို တွက်သည်
                double currentWallSegment;
                if (isFirst)
                {
                    currentWallSegment = Math.Min(maxSegmentFt - leftTail, remainingWallLength);
                }
                else
                {
                    currentWallSegment = Math.Min(maxSegmentFt, remainingWallLength);
                }

                // Wall ပေါ်က အစမှတ်နှင့် အဆုံးမှတ်
                XYZ segStart = exStart + _wallDirection * currentOffset;
                XYZ segEnd = segStart + _wallDirection * currentWallSegment;

                // ⭐ Tail (Anchor) ထည့်သွင်းခြင်း
                // ဤနေရာတွင် Anchor ကို ပေါင်းထည့်သော်လည်း Segment စုစုပေါင်းအရှည်သည် ၈ မီတာထက် မကျော်တော့ပါ
                // ⭐ Anchor ရှိရင် Wall အပြင်ထွက်၊ မရှိရင် Cover ချန်
                if (isFirst)
                {
                    if (leftTail > 0) segStart -= _wallDirection * leftTail; // Anchor အတိအကျထွက်မယ်
                    else segStart += _wallDirection * _sideCover; // Anchor မရှိမှ Cover ချန်မယ်
                }

                // နောက်ဆုံး Segment ဖြစ်ပါက Right Tail ထည့်ရန် ကျန်ရှိသော Segment length ထဲတွင် Right Tail ဆံ့/မဆံ့ စစ်ဆေးနိုင်သည်
                // (မှတ်ချက် - Right Tail ကြောင့် ၈ မီတာ ကျော်နိုင်ပါက အလားတူ Logic သုံးနိုင်ပါသည်)
                bool isLast = (currentOffset + currentWallSegment >= usableLength - 0.001);
                if (isLast)
                {
                    if (rightTail > 0) segEnd += _wallDirection * rightTail; // Anchor အတိအကျ
                    else segEnd -= _wallDirection * _sideCover; // Anchor မရှိမှ Cover နှုတ်မယ်
                }

                Line barLine = Line.CreateBound(segStart, segEnd);

                var bar = Autodesk.Revit.DB.Structure.Rebar.CreateFromCurves(
                    _doc, RebarStyle.Standard, _externalHBar,
                    isFirst ? startHook : null,
                    isLast ? endHook : null,
                    _hostElement, XYZ.BasisZ, new List<Curve> { barLine },
                    startOrient, endOrient, true, true);

                // အဟောင်း: ApplyBarLayout(bar, height, totalHBars, _externalHBarSpacing, true);
                // အသစ် (HFN လုံးဝဖြုတ်ပြီး Spacing သက်သက်သုံးရန်):
                bar.GetShapeDrivenAccessor().SetLayoutAsMaximumSpacing(_externalHBarSpacing, height, true, true, true);

                if (firstBar == null) firstBar = bar;

                // Offset ကို Wall Length အတိုင်းသာ တိုးသွားသည်
                currentOffset += currentWallSegment;

                // Overlap (Joint) Bar ထည့်ခြင်း
                if (currentOffset < usableLength)
                {
                    XYZ overlapStart = exStart + _wallDirection * (currentOffset - (spacingFt / 2));
                    XYZ overlapEnd = overlapStart + _wallDirection * spacingFt;
                    Line overlapLine = Line.CreateBound(overlapStart, overlapEnd);

                    var overlapBar = Autodesk.Revit.DB.Structure.Rebar.CreateFromCurves(
                        _doc, RebarStyle.Standard, _exHJointBar, null, null,
                        _hostElement, XYZ.BasisZ, new List<Curve> { overlapLine },
                        startOrient, endOrient, true, true);

                    overlapBar.GetShapeDrivenAccessor().SetLayoutAsMaximumSpacing(_externalHBarSpacing, height, true, true, true);
                }
            }

            return firstBar;
        }

        // ==========================================
        // INTERNAL HORIZONTAL
        // ==========================================
        private Autodesk.Revit.DB.Structure.Rebar CreateInternalHorizontalRebar()
        {
            // 1. Spacing/Joint Length သတ်မှတ်ခြင်း
            double spacingFt = _rebarDto.InHLeftJointLength;
            if (spacingFt < 0.001) spacingFt = UnitUtils.ConvertToInternalUnits(1, UnitTypeId.Millimeters);

            // 2. Start Point တွက်ချက်ခြင်း (Interior Face)
            XYZ intSurf = GetProjectedPointOnFace(_interiorFace, _wallStartPoint);
            double barRadius = _internalHBar.BarNominalDiameter / 2.0;
            double startZ = intSurf.Z + _wallBaseOffset + _sideCover + barRadius;

            XYZ horizontalBaseXY = intSurf + (_interiorFaceNormal.Negate() * (_sideCover + barRadius));
            XYZ inStart = new XYZ(horizontalBaseXY.X, horizontalBaseXY.Y, startZ);
            // Start point ကို side cover နေရာကနေ စပါ
            //inStart = inStart + (_wallDirection * _sideCover);

            // 3. Parameters
            //double usableLength = _wallLength - (2 * _sideCover);
            double usableLength = _wallLength;
            var startHook = _internalHStartHookType == "None" ? null : ResolveHook(_internalHStartHookType);
            var endHook = _internalHEndHookType == "None" ? null : ResolveHook(_internalHEndHookType);
            var startOrient = _internalHStartOrientation == "Right" ? RebarHookOrientation.Right : RebarHookOrientation.Left;
            var endOrient = _internalHEndOrientation == "Right" ? RebarHookOrientation.Right : RebarHookOrientation.Left;

            // ⭐ အလိုအလျောက် Extension တွက်ချက်ခြင်း
            double autoLeftTail = Math.Max(0, GetCornerExtension(_hostElement, 0));
            double autoRightTail = Math.Max(0, GetCornerExtension(_hostElement, 1));

            // User ပေးထားတဲ့ Anchor နဲ့ အလိုအလျောက်တွက်ထားတာထဲက ပိုကြီးတာကို ယူနိုင်ပါတယ်
            double leftTail = _internalHLeftAnchorLengthFt + autoLeftTail;
            double rightTail = _internalHRightAnchorLengthFt + autoRightTail;
            double height = _wallHeight - (2 * _sideCover);

            // ၈ မီတာ ကန့်သတ်ချက်
            double maxSegmentFt = UnitUtils.ConvertToInternalUnits(8000, UnitTypeId.Millimeters);

            Autodesk.Revit.DB.Structure.Rebar firstBar = null;
            double currentOffset = 0.0;

            while (currentOffset < usableLength)
            {
                bool isFirst = (currentOffset == 0);
                double remainingWallLength = usableLength - currentOffset;

                // ⭐ Logic အသစ် - Anchor ပါဝင်ပါက ၈ မီတာထက် မကျော်အောင် တွက်ချက်ခြင်း
                double currentWallSegment;
                if (isFirst)
                {
                    // ပထမဆုံးတိုင်မှာ Anchor (leftTail) ကို နှုတ်ပြီးမှ ကျန်တဲ့ wall length ကိုယူတယ်
                    currentWallSegment = Math.Min(maxSegmentFt - leftTail, remainingWallLength);
                }
                else
                {
                    currentWallSegment = Math.Min(maxSegmentFt, remainingWallLength);
                }

                XYZ segStart = inStart + _wallDirection * currentOffset;
                XYZ segEnd = segStart + _wallDirection * currentWallSegment;

                // Tail ထည့်သော်လည်း စုစုပေါင်းအရှည်သည် ၈ မီတာထက် မပိုတော့ပါ
                if (isFirst)
                {
                    if (leftTail > 0) segStart -= _wallDirection * leftTail; // Anchor အတိအကျထွက်မယ်
                    else segStart += _wallDirection * _sideCover; // Anchor မရှိမှ Cover ချန်မယ်
                }

                bool isLast = (currentOffset + currentWallSegment >= usableLength - 0.001);
                if (isLast)
                {
                    if (rightTail > 0) segEnd += _wallDirection * rightTail; // Anchor အတိအကျ
                    else segEnd -= _wallDirection * _sideCover; // Anchor မရှိမှ Cover နှုတ်မယ်
                }

                Line barLine = Line.CreateBound(segStart, segEnd);

                var bar = Autodesk.Revit.DB.Structure.Rebar.CreateFromCurves(
                    _doc, RebarStyle.Standard, _internalHBar,
                    isFirst ? startHook : null,
                    isLast ? endHook : null,
                    _hostElement, XYZ.BasisZ, new List<Curve> { barLine },
                    startOrient, endOrient, true, true);

                bar.GetShapeDrivenAccessor().SetLayoutAsMaximumSpacing(_internalHBarSpacing, height, true, true, true);

                if (firstBar == null) firstBar = bar;

                currentOffset += currentWallSegment;

                // Joint (Overlap) Bar
                if (currentOffset < usableLength)
                {
                    XYZ overlapStart = inStart + _wallDirection * (currentOffset - (spacingFt / 2));
                    XYZ overlapEnd = overlapStart + _wallDirection * spacingFt;
                    Line overlapLine = Line.CreateBound(overlapStart, overlapEnd);

                    var overlapBar = Autodesk.Revit.DB.Structure.Rebar.CreateFromCurves(
                        _doc, RebarStyle.Standard, _inHJointBar, null, null,
                        _hostElement, XYZ.BasisZ, new List<Curve> { overlapLine },
                        startOrient, endOrient, true, true);

                    overlapBar.GetShapeDrivenAccessor().SetLayoutAsMaximumSpacing(_internalHBarSpacing, height, true, true, true);
                }
            }

            return firstBar;
        }

        // ==========================================
        // SINGLE EXTERNAL HORIZONTAL (NO SIDE COVER)
        // ==========================================
        private Autodesk.Revit.DB.Structure.Rebar CreateSingleExternalHorizontalRebarWithoutCover()
        {
            // 1. Spacing/Joint Length သတ်မှတ်ခြင်း
            double spacingFt = _rebarDto.ExHLeftJointLength;
            if (spacingFt < 0.001) spacingFt = UnitUtils.ConvertToInternalUnits(1, UnitTypeId.Millimeters);

            // 2. Start Point တွက်ချက်ခြင်း
            XYZ extSurf = GetProjectedPointOnFace(_exteriorFace, _wallStartPoint);
            double barRadius = _externalHBar.BarNominalDiameter / 2.0;

            // Z offset အတွက်ကတော့ အောက်ခြေ Cover စာ ချန်ထားပါမည်
            double startZ = extSurf.Z + _wallBaseOffset + _sideCover + barRadius;

            XYZ horizontalBaseXY = extSurf + (_exteriorFaceNormal.Negate() * (_sideCover + barRadius));
            XYZ exStart = new XYZ(horizontalBaseXY.X, horizontalBaseXY.Y, startZ);

            // မှတ်ချက် - Cover စာမချန်ဘဲ Wall အစကနေပဲ တိုက်ရိုက်စပါမည်

            // အလိုအလျောက် Extension တွက်ချက်ခြင်းကို ဦးစွာရယူပါ
            double autoLeftTail = Math.Max(0, GetCornerExtension(_hostElement, 0));
            double autoRightTail = Math.Max(0, GetCornerExtension(_hostElement, 1));
            // User ပေးထားတဲ့ Anchor နဲ့ အလိုအလျောက်တွက်ထားတာထဲက ပိုကြီးတာကို ယူနိုင်ပါတယ်
            double leftTail = _externalHLeftAnchorLengthFt + autoLeftTail;
            double rightTail = _externalHRightAnchorLengthFt + autoRightTail;

            // 3. Parameters
            // ⭐ အဓိက ပြင်ဆင်ချက် - Usable Length ထဲသို့ ဘယ်ညာ Extension (Tail) များကိုပါ ပေါင်းထည့်ပေးပါ
            double usableLength = _wallLength + leftTail + rightTail;

            // ⭐ Start Point ကို ဘယ်ဘက် Extension (leftTail) ပမာဏအလျောက် အပြင်ဘက်သို့ တိုးထုတ်ပေးပါ
            exStart = exStart - (_wallDirection * leftTail);

            var startHook = _externalHStartHookType == "None" ? null : ResolveHook(_externalHStartHookType);
            var endHook = _externalHEndHookType == "None" ? null : ResolveHook(_externalHEndHookType);
            var startOrient = _externalHStartOrientation == "Right" ? RebarHookOrientation.Right : RebarHookOrientation.Left;
            var endOrient = _externalHEndOrientation == "Right" ? RebarHookOrientation.Right : RebarHookOrientation.Left;

            double height = _wallHeight - (2 * _sideCover);

            double maxSegmentFt = UnitUtils.ConvertToInternalUnits(8000, UnitTypeId.Millimeters);

            Autodesk.Revit.DB.Structure.Rebar firstBar = null;
            double currentOffset = 0.0;

            while (currentOffset < usableLength)
            {
                double remainingWallLength = usableLength - currentOffset;
                double currentWallSegment = Math.Min(maxSegmentFt, remainingWallLength);

                XYZ segStart = exStart + _wallDirection * currentOffset;
                XYZ segEnd = segStart + _wallDirection * currentWallSegment;

                Line barLine = Line.CreateBound(segStart, segEnd);

                bool isFirst = (currentOffset == 0);
                bool isLast = (currentOffset + currentWallSegment >= usableLength - 0.001);

                var bar = Autodesk.Revit.DB.Structure.Rebar.CreateFromCurves(
                    _doc, RebarStyle.Standard, _externalHBar,
                    isFirst ? startHook : null,
                    isLast ? endHook : null,
                    _hostElement, XYZ.BasisZ, new List<Curve> { barLine },
                    startOrient, endOrient, true, true);

                bar.GetShapeDrivenAccessor().SetLayoutAsMaximumSpacing(_externalHBarSpacing, height, true, true, true);

                if (firstBar == null) firstBar = bar;

                currentOffset += currentWallSegment;

                if (currentOffset < usableLength)
                {
                    XYZ overlapStart = exStart + _wallDirection * (currentOffset - (spacingFt / 2));
                    XYZ overlapEnd = overlapStart + _wallDirection * spacingFt;
                    Line overlapLine = Line.CreateBound(overlapStart, overlapEnd);

                    var overlapBar = Autodesk.Revit.DB.Structure.Rebar.CreateFromCurves(
                        _doc, RebarStyle.Standard, _exHJointBar, null, null,
                        _hostElement, XYZ.BasisZ, new List<Curve> { overlapLine },
                        startOrient, endOrient, true, true);

                    overlapBar.GetShapeDrivenAccessor().SetLayoutAsMaximumSpacing(_externalHBarSpacing, height, true, true, true);
                }
            }

            return firstBar;
        }

        // Single Rebar external-only method
        private RebarSetsResultDto BuildSingleExternalRebar()
        {
            // Cover ကို wall thickness / 2 သုံးမယ်
            double wallThkMm = UnitUtils.ConvertFromInternalUnits(_wallThickness, UnitTypeId.Millimeters);
            _sideCover = UnitUtils.ConvertToInternalUnits(wallThkMm / 2.0, UnitTypeId.Millimeters);

            // External Vertical Bar
            var externalVBarSet = CreateExternalVerticalRebar();

            // External Horizontal Bar
            var externalHBarSet = CreateSingleExternalHorizontalRebarWithoutCover();

            // Internal bars skipped
            return new RebarSetsResultDto(externalVBarSet, null, externalHBarSet, null, null, null, null);
        }

        // ==========================================
        // LEFT U-BAR (Modified)
        // ==========================================
        private Autodesk.Revit.DB.Structure.Rebar CreateLeftUBar()
        {
            if (_interiorFace == null || _exteriorFace == null)
                throw new Exception("Wall faces not resolved. Check offset propagation.");

            // Horizontal Bar ရဲ့ Parameters တွေကို အတိအကျ ယူပါ (Alignment တူစေရန်)
            double hBarSpacing = _internalHBarSpacing;

            // XY အတွက်ကတော့ U-Bar ရဲ့ Radius ကိုပဲ သုံးပါ (နံရံမျက်နှာပြင်နဲ့ ကပ်နေအောင်)
            double uBarRadius = _uBar.BarNominalDiameter / 2.0; // Internal Unit (Feet)

            // ⭐ Extension Length ကို အရင်ယူပါ
            double leftExt = GetCornerExtension(_hostElement, 0);

            // ⭐ Extension ရှိရင် Cover 0၊ မရှိရင် Side Cover ယူမယ်
            double actualSideCover = (leftExt > 0) ? 0 : _sideCover;
            double offsetDistFromFace = _sideCover + uBarRadius; // Face ကနေ ဝင်မယ့် offset (ဒါကတော့ ပုံသေပဲ)
            double offsetDistFromEnd = actualSideCover + uBarRadius; // Wall အစွန်းကနေ ဝင်မယ့် offset

            // Wall ရဲ့ Start Point ကို Extension ရှိသလောက် အပြင်ဘက်ကို ဆွဲထုတ်လိုက်ခြင်း (Direction ကို နှုတ်တာပါ)
            XYZ intSurf = GetProjectedPointOnFace(_interiorFace, _wallStartPoint) - (_wallDirection * leftExt);
            XYZ extPt = GetProjectedPointOnFace(_exteriorFace, _wallStartPoint) - (_wallDirection * leftExt);
            XYZ intPt = intSurf;

            // Base Offset ကို ပေါင်းထည့်ခြင်း
            double z = intSurf.Z + _wallBaseOffset + _sideCover + uBarRadius;

            // Face Normal အတိုင်း ဝင်တာကတော့ ပုံသေပဲ (Top/Bottom logic)
            XYZ p2 = extPt + (_exteriorFaceNormal.Negate() * offsetDistFromFace);
            XYZ p3 = intPt + (_interiorFaceNormal.Negate() * offsetDistFromFace);

            // ⭐ Wall အစွန်းကနေ ဝင်မယ့် offset ကို actualSideCover သုံးပြီး တွက်ပါမယ်
            p2 = p2 + (_wallDirection * offsetDistFromEnd);
            p3 = p3 + (_wallDirection * offsetDistFromEnd);

            // ပြင်ဆင်ထားသော အပိုင်း (UI မှ တန်ဖိုးကိုယူပြီး Radius နုတ်ခြင်း)
            double targetJointFt = _rebarDto.InHLeftJointLength > 0 ? _rebarDto.InHLeftJointLength : UnitUtils.ConvertToInternalUnits(200.0, UnitTypeId.Millimeters);
            double legLen = targetJointFt - uBarRadius;
            XYZ p1 = p2 + (_wallDirection * legLen);
            XYZ p4 = p3 + (_wallDirection * legLen);

            // Z Level ကို Alignment ညှိပါ
            p1 = new XYZ(p1.X, p1.Y, z);
            p2 = new XYZ(p2.X, p2.Y, z);
            p3 = new XYZ(p3.X, p3.Y, z);
            p4 = new XYZ(p4.X, p4.Y, z);

            List<Curve> curves = new List<Curve> { Line.CreateBound(p1, p2), Line.CreateBound(p2, p3), Line.CreateBound(p3, p4) };

            var bar = Autodesk.Revit.DB.Structure.Rebar.CreateFromCurves(
                _doc, RebarStyle.Standard, _uBar, null, null,
                _hostElement, XYZ.BasisZ, curves,
                RebarHookOrientation.Right, RebarHookOrientation.Right, true, true);

            // Layout Height ကို Horizontal Bar ရဲ့ Method ထဲက math အတိုင်း အတိအကျ ရေးပါ
            // Horizontal Bar မှာ height = _wallHeight - (2 * _sideCover) လို့ သုံးထားလို့ ဒီမှာလည်း ထပ်တူ ဖြစ်ရမယ်
            double distributionHeight = _wallHeight - (2 * _sideCover);

            // Spacing လည်း Horizontal Spacing ကိုပဲ သုံးပါ
            bar.GetShapeDrivenAccessor().SetLayoutAsMaximumSpacing(hBarSpacing, distributionHeight, true, true, true);

            return bar;
        }

        // ==========================================
        // RIGHT U-BAR (Modified)
        // ==========================================
        private Autodesk.Revit.DB.Structure.Rebar CreateRightUBar()
        {
            if (_interiorFace == null || _exteriorFace == null)
                throw new Exception("Wall faces not resolved. Check offset propagation.");

            // Horizontal Bar ရဲ့ Parameters တွေကို အတိအကျ ယူပါ (Alignment တူစေရန်)
            double hBarSpacing = _internalHBarSpacing;

            // XY အတွက် U-Bar ရဲ့ Radius ကို သုံးပါ (Cover လွတ်စေရန်)
            double uBarRadius = _uBar.BarNominalDiameter / 2.0;

            // ⭐ Extension Length ကို ယူပါ
            double rightExt = GetCornerExtension(_hostElement, 1);

            // ⭐ Extension ရှိရင် Cover 0၊ မရှိရင် Side Cover ယူမယ်
            double actualSideCover = (rightExt > 0) ? 0 : _sideCover;
            double offsetDistFromFace = _sideCover + uBarRadius;
            double offsetDistFromEnd = actualSideCover + uBarRadius;

            // Wall ရဲ့ End Point ကို Extension ရှိသလောက် အပြင်ဘက်ကို ထပ်တိုးလိုက်ခြင်း (Direction ကို ပေါင်းတာပါ)
            XYZ intSurf = GetProjectedPointOnFace(_interiorFace, _wallEndPoint) + (_wallDirection * rightExt);
            XYZ extPt = GetProjectedPointOnFace(_exteriorFace, _wallEndPoint) + (_wallDirection * rightExt);
            XYZ intPt = intSurf;

            double z = intSurf.Z + _wallBaseOffset + _sideCover + uBarRadius;

            // Face များမှ အတွင်းသို့ Offset ချခြင်း
            XYZ p2 = extPt + (_exteriorFaceNormal.Negate() * offsetDistFromFace);
            XYZ p3 = intPt + (_interiorFaceNormal.Negate() * offsetDistFromFace);

            // ⭐ Right Edge ဖြစ်တဲ့အတွက် Wall Direction ကို "နုတ်" ပြီး အထဲသို့ သွင်းရပါမယ်
            p2 = p2 - (_wallDirection * offsetDistFromEnd);
            p3 = p3 - (_wallDirection * offsetDistFromEnd);

            // ပြင်ဆင်ထားသော အပိုင်း (UI မှ တန်ဖိုးကိုယူပြီး Radius နုတ်ခြင်း)
            double targetJointFt = _rebarDto.InHLeftJointLength > 0 ? _rebarDto.InHLeftJointLength : UnitUtils.ConvertToInternalUnits(200.0, UnitTypeId.Millimeters);
            double legLen = targetJointFt - uBarRadius;
            XYZ p1 = p2 - (_wallDirection * legLen);
            XYZ p4 = p3 - (_wallDirection * legLen);

            // Z Level ကို Alignment ညှိခြင်း
            p1 = new XYZ(p1.X, p1.Y, z);
            p2 = new XYZ(p2.X, p2.Y, z);
            p3 = new XYZ(p3.X, p3.Y, z);
            p4 = new XYZ(p4.X, p4.Y, z);

            List<Curve> curves = new List<Curve> { Line.CreateBound(p1, p2), Line.CreateBound(p2, p3), Line.CreateBound(p3, p4) };

            var bar = Autodesk.Revit.DB.Structure.Rebar.CreateFromCurves(
                _doc, RebarStyle.Standard, _uBar, null, null,
                _hostElement, XYZ.BasisZ, curves,
                RebarHookOrientation.Right, RebarHookOrientation.Right, true, true);

            // ၄။ Layout Height ကို Horizontal Bar အတိုင်း အတိအကျ ညှိပါ
            // Horizontal Bar: height = _wallHeight - (2 * _sideCover)
            double distributionHeight = _wallHeight - (2 * _sideCover);

            // Spacing နဲ့ Height ကို Horizontal Bar အတိုင်း ပေးလိုက်ခြင်းဖြင့် လုံးဝ တစ်ထပ်တည်း ကျသွားပါလိမ့်မယ်
            bar.GetShapeDrivenAccessor().SetLayoutAsMaximumSpacing(hBarSpacing, distributionHeight, true, true, true);

            return bar;
        }

        // ==========================================
        // CAP TIE LOGIC (FIXED)
        // ==========================================
        public List<Autodesk.Revit.DB.Structure.Rebar> CreateMultipleVerticalCapTie()
        {
            List<Autodesk.Revit.DB.Structure.Rebar> bars = new List<Autodesk.Revit.DB.Structure.Rebar>();

            // ၁၀၀၀ မီလီမီတာ အကွာအဝေး
            double spacingTargetMm = 1000;
            double spacingTargetFt = UnitConventions.MmToFeet(spacingTargetMm);
            double coverFt = UnitConventions.MmToFeet(_rebarDto.Cover);

            // -- ပြင်ဆင်ချက် ၁။ Wall Length ကို စစ်ဆေးခြင်း --
            double wallLengthMm = UnitConventions.FtToMm(_wallLength);
            List<double> xDistancesFt = new List<double>();

            if (wallLengthMm < 1000)
            {
                // အလျား 1000 အောက်ဆိုလျှင် အလယ်ဗဟို (Midpoint) တွင်သာ ထားရန်
                xDistancesFt.Add(_wallLength / 2.0);
            }
            else
            {
                // အလျား 1000 နှင့် အထက်ဆိုလျှင် မူလအတိုင်း ၁၀၀၀ စီခြားရန်
                int numberHorizontal = (int)((_wallLength - (2 * coverFt)) / spacingTargetFt);
                for (int i = 1; i <= numberHorizontal; i++)
                {
                    double distFromStart = coverFt + (i * spacingTargetFt);
                    if (distFromStart > (_wallLength - coverFt)) break;

                    xDistancesFt.Add(distFromStart);
                }
            }

            // ရရှိလာသော X နေရာတိုင်းတွင် Cap Tie လိုက်ဆောက်ရန်
            foreach (double distFromStart in xDistancesFt)
            {
                XYZ basePoint = _wallStartPoint + (_wallDirection * distFromStart);
                XYZ basePointWithOffset = new XYZ(basePoint.X, basePoint.Y, basePoint.Z + _wallBaseOffset);

                try
                {
                    // CreateVerticalCapTie သို့ spacingTargetFt ကို ပေးပို့ရန်
                    Autodesk.Revit.DB.Structure.Rebar bar = CreateVerticalCapTie(basePointWithOffset, coverFt, spacingTargetFt);
                    if (bar != null) bars.Add(bar);
                }
                catch { /* Error Handling */ }
            }

            return bars;
        }

        private Autodesk.Revit.DB.Structure.Rebar CreateVerticalCapTie(XYZ basePoint, double sideCover, double capTieSpacing)
        {
            double uBarDia = _capTieBar.BarModelDiameter;
            double wallHeightMm = UnitConventions.FtToMm(_wallHeight);

            double startZ;
            int numberOfBars;

            // ၁။ Height ပေါ်မူတည်ပြီး အရေအတွက်နှင့် စမှတ်ကို တွက်ချက်ခြင်း
            if (wallHeightMm < 1000)
            {
                // အမြင့် 1000 အောက်ဆိုလျှင် ဗဟိုမှာ ၁ ခုတည်း
                startZ = basePoint.Z + (_wallHeight / 2.0);
                numberOfBars = 1;
            }
            else
            {
                // ၁၀၀၀ အထက်ဆိုလျှင်- အောက်ဆုံးမှ ၁၀၀၀ ခွာပြီး စတင်မည်
                // ထို့နောက် ကျန်ရှိသော အမြင့်အတွင်း ၁၀၀၀ စီ ခြား၍ ဘယ်နှစ်ခု ဆောက်နိုင်မလဲ တွက်မည်
                startZ = basePoint.Z + capTieSpacing;
                double remainingHeight = _wallHeight - capTieSpacing - sideCover; // အပေါ် Cover ထိ ကျန်သော အကွာအဝေး
                numberOfBars = (int)(remainingHeight / capTieSpacing) + 1;
            }

            // ၂။ ပထမဆုံး Cap Tie ၏ နေရာကို သတ်မှတ်ခြင်း
            XYZ basePointAtZ = new XYZ(basePoint.X, basePoint.Y, startZ);
            // Curve ဆွဲခြင်း 
            double halfThickness = _hostElement.Width / 2.0;
            double offsetDist = halfThickness - sideCover - (uBarDia / 2.0);
            XYZ p1 = basePointAtZ + (_exteriorFaceNormal * offsetDist);
            double distBetweenBars = _hostElement.Width - (2 * sideCover) - uBarDia;
            XYZ p2 = p1 + (_interiorFaceNormal * distBetweenBars);

            IList<Curve> curves = new List<Curve> { Line.CreateBound(p1, p2) };

            // ၃။ Rebar ကို Revit ထဲတွင် ဆောက်ခြင်
            Autodesk.Revit.DB.Structure.Rebar bar = Autodesk.Revit.DB.Structure.Rebar.CreateFromCurves(
                _doc, RebarStyle.Standard, _capTieBar, null, null, _hostElement,
                XYZ.BasisZ, curves, RebarHookOrientation.Right, RebarHookOrientation.Right, true, true);

            // ၄။ Layout (Array) သတ်မှတ်ခြင်း
            if (bar != null)
            {
                if (numberOfBars <= 1)
                {
                    bar.GetShapeDrivenAccessor().SetLayoutAsSingle();
                }
                else
                {
                    // တိကျစေရန် Number With Spacing ကို သုံးပြီး Array ပွားပါ
                    bar.GetShapeDrivenAccessor().SetLayoutAsNumberWithSpacing(numberOfBars, capTieSpacing, true, true, true);
                }
            }
            return bar;
        }

        private RebarHookType ResolveHook(string hookTypeName)
        {
            if (string.IsNullOrWhiteSpace(hookTypeName) || hookTypeName == "None")
                return null;

            // ⭐ RebarHookHelper ထဲရှိ GetRebarHookType ကို အသုံးပြု၍ ရှာမည် (မတွေ့ပါက တိကျသော Error Message ထွက်မည်)
            try
            {
                // hookTypeName ထဲမှ Degree (ဥပမာ - "90") သို့မဟုတ် နာမည်အပြည့်အစုံကို ယူသုံးခြင်း ("90" ဟု ဝင်လာပါက Revit ထဲတွင် အမှန်တကယ်ရှိသော "Standard - 90 deg" သို့ ရှာဖွေပေးမည်)
                string keyword = hookTypeName.Contains("90") ? "Standard - 90 deg" : hookTypeName;
                return RebarHookHelper.GetRebarHookType(_doc, keyword);
            }
            catch (Exception ex)
            {

                string availableHooks = string.Join(", ", new FilteredElementCollector(_doc)
                    .OfClass(typeof(RebarHookType))
                    .Cast<RebarHookType>()
                    .Select(h => h.Name));
                throw new InvalidOperationException($"Could not find Rebar Hook Type containing '{hookTypeName}'. Available hooks in project: [{availableHooks}]. Error: {ex.Message}");
            }
        }

        // Unbounded Plane Projection Method (တိကျမှုလွဲချော်ခြင်းမှ ကာကွယ်ရန်)
        private XYZ GetProjectedPointOnFace(Face face, XYZ point)
        {
            if (face is PlanarFace pf)
            {
                // မျက်နှာပြင်ကို အဆုံးအစမဲ့ ပြင်ညီတစ်ခုအဖြစ် သတ်မှတ်ပြီး တွက်ချက်ခြင်း
                double distance = (point - pf.Origin).DotProduct(pf.FaceNormal);
                return point - (pf.FaceNormal * distance);
            }

            // Planar မဟုတ်ခဲ့ရင် မူလ Project ကို ပြန်သုံးမည်
            IntersectionResult res = face?.Project(point);
            return (res != null) ? res.XYZPoint : point;
        }

        // FN / HFN တန်ဖိုးနှင့် Spacing များကို Error မတက်စေဘဲ လုံခြုံစွာ တွက်ချက်ပေးမည့် Layout များကို ပုံစံတူ စီမံပေးမည့် သီးသန့် Helper Method
        private void ApplyBarLayout(Autodesk.Revit.DB.Structure.Rebar rebar, double length, double totalBars, double defaultSpacing, bool isCeiling)
        {
            if (rebar == null) return;

            try
            {
                if (totalBars > 0 && length > 0)
                {
                    // မစုံဂဏန်းများအတွက် တစ်ဖက်ကို အနည်းငယ်ပိုပေးရန် (Ceiling သို့မဟုတ် Floor သုံးခြင်း)
                    int barsPerFace = Math.Max(1, (int)(isCeiling ? Math.Ceiling(totalBars / 2.0) : Math.Floor(totalBars / 2.0)));
                    int spaces = Math.Max(1, barsPerFace - 1);
                    double calculatedSpacing = length / spaces;

                    rebar.GetShapeDrivenAccessor().SetLayoutAsNumberWithSpacing(barsPerFace, calculatedSpacing, true, true, true);
                    return;
                }
                if (defaultSpacing > 0)
                {
                    // Spacing Mode သုံးခြင်း HFN not set → use spacing mode (FN/HFN မရှိပါက သို့မဟုတ် Error တက်ပါက Spacing စနစ်အတိုင်း သုံးမည်)
                    rebar.GetShapeDrivenAccessor().SetLayoutAsMaximumSpacing(defaultSpacing, length, true, true, true);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"ApplyBarLayout Error: {ex.Message}");
            }
        }
    }
}