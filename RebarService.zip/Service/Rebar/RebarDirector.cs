﻿using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using SkyK.MPaManager;
using Structural_WinForm_Project_Sky_K_Solution.Models;
using Structural_WinForm_Project_Sky_K_Solution.Helpers;

namespace Structural_WinForm_Project_Sky_K_Solution.Service.Rebar;

public class RebarDirector
{
    public RebarSetsResultDto ConstructRebarSet(
        IRebarBuilder builder,
        RebarDto dto,
        WallDto wdto,
        Autodesk.Revit.DB.Wall hostWall)
    {
        // (၁) Revit Schedule အတွက် Parameter များ Update လုပ်ခြင်း
        UpdateScheduleParameters(hostWall, dto);

        // ⭐ Wall Name မှ _220mm ကဲ့သို့သော Suffix များကို ဖယ်ရှားခြင်း
        string cleanWallName = WallNameHelper.GetCleanWallName(wdto.WallName);

        builder
            .SetHost(hostWall)
            .SetRebarDto(dto)
            .SetGeometry()
            .SetRebarType(cleanWallName, dto.InVBarDia, dto.ExVBarDia, dto.InHBarDia, dto.ExHBarDia , dto.UBarDia)
            .SetRebarShape()
            .SetCover(dto.Cover)
            .SetSpacing(dto.InVBarSpacing, dto.ExVBarSpacing, dto.InHBarSpacing, dto.ExHBarSpacing, dto.ExHBarSpacing)
            .SetUBarSide(dto.IsUbar, dto.UBarSide)
            .SetSlabTHK(dto.SlabTHK);
        //.SetExternalVSlab(dto.ExVBelowSlabThickness, dto.ExVTopSlabThickness)
        //.SetInternalVSlab(dto.InVBelowSlabThickness, dto.InVTopSlabThickness)
        //.SetExternalHSlab(dto.ExHLeftSlabThickness, dto.ExHRightSlabThickness)
        //.SetInternalHSlab(dto.InHLeftSlabThickness, dto.InHRightSlabThickness)

        // --- Vertical hooks + lengths by floor ---
        if (dto.IsLowestFloor) 
        {
            builder
                .SetFoundationThickness(dto.FoundationTHK)
                .SetInternalVHooks(dto.InVBelowHookType, "None", "Left", "Left") 
                .SetExternalVHooks(dto.ExVBelowHookType, "None", "Left", "Left") 
                .SetInternalVLengths(dto.InVBelowAnchorLength, dto.InVTopJointLength) 
                .SetExternalVLengths(dto.ExVBelowAnchorLength, dto.ExVTopJointLength); 
        }
        else if (dto.IsMiddleFloor)
        {
            builder // Middle floor → only use TopJointM values, ignore lowest floor inputs
                .SetInternalVHooks("None", "None", "None", "None")
                .SetExternalVHooks("None", "None", "None", "None")
                .SetMiddleFloorLengths(dto.InVTopJointM, dto.ExVTopJointM);
        }
        else if (dto.IsTopFloor) 
        { 
            builder 
                .SetInternalVHooks("None", dto.InVTopHookType, "None", "Left") 
                .SetExternalVHooks("None", dto.ExVTopHookType, "None", "Left")
                .SetInternalVLengths(0, 0) 
                .SetExternalVLengths(0, 0);
        }
        else if (dto.IsOnlyFloor) 
        {
            builder
                .SetFoundationTHK(dto.FoundationTHKO)
                .SetInternalVHooks(dto.InBottomHookO, dto.InTopHookO, "Left", "Left")
                .SetExternalVHooks(dto.ExBottomHookO, dto.ExTopHookO, "Left", "Left")
                .SetInternalVLengths(dto.InBottomJointO, 0)
                .SetExternalVLengths(dto.ExBottomJointO, 0); 
        }
        else
        {
            builder // fallback (if none of the floor checkboxes are ticked)
                .SetInternalVHooks("None", "None", "None", "None") 
                .SetExternalVHooks("None", "None", "None", "None") 
                .SetInternalVLengths(0, 0) 
                .SetExternalVLengths(0, 0); 
        }

        double finalExLeftLen = 0, finalExRightLen = 0;
        double finalInLeftLen = 0, finalInRightLen = 0;

        // --- ၁။ ဘယ်ဘက် (LEFT) အတွက် Length စစ်ဆေးခြင်း ---
        // Anchor ရွေးထားရင် Anchor ကို ယူမယ်၊ မရွေးထားရင် Joint ကို စစ်မယ်
        if (dto.IsAnchor && (dto.AnchorSide == AnchorSide.Left || dto.AnchorSide == AnchorSide.Both))
        {
            finalExLeftLen = dto.ExHLeftAnchorLength;
            finalInLeftLen = dto.InHLeftAnchorLength;
        }
        else if (dto.IsJoint && (dto.JointSide == JointSide.Left || dto.JointSide == JointSide.Both))
        {
            finalExLeftLen = dto.ExHLeftJointLength;
            finalInLeftLen = dto.InHLeftJointLength;
        }

        // --- ၂။ ညာဘက် (RIGHT) အတွက် Length စစ်ဆေးခြင်း ---
        if (dto.IsAnchor && (dto.AnchorSide == AnchorSide.Right || dto.AnchorSide == AnchorSide.Both))
        {
            finalExRightLen = dto.ExHRightAnchorLength;
            finalInRightLen = dto.InHRightAnchorLength;
        }
        else if (dto.IsJoint && (dto.JointSide == JointSide.Right || dto.JointSide == JointSide.Both))
        {
            finalExRightLen = dto.ExHRightJointLength;
            finalInRightLen = dto.InHRightJointLength;
        }

        // Builder ထံသို့ Length များကို တစ်ကြိမ်တည်း ပေးပို့ခြင်း (Overwrite ပြဿနာ ကင်းဝေးသွားပါမည်)
        builder.SetExternalHLengths(finalExLeftLen, finalExRightLen)
               .SetInternalHLengths(finalInLeftLen, finalInRightLen);


        // --- ၃။ HOOK သတ်မှတ်ခြင်း (Length များနှင့် လုံးဝ မသက်ဆိုင်ဘဲ သီးသန့် အလုပ်လုပ်မည်) ---
        string leftHookName = "None";
        string rightHookName = "None";
        string hookType = "Standard - 90 deg"; // Revit ထဲတွင် အမှန်တကယ်ရှိသော Hook အမည်ဖြစ်ရမည်
        string hookOri = "Right"; // Default Orientation

        if (dto.IsHook)
        {
            // Left (သို့) Both Checkbox မှန်နေရင် Left Hook ထည့်မယ် (Length က 0 ဖြစ်နေလည်း ထွက်လာမယ်)
            if (dto.HookSide == HookSide.Left || dto.HookSide == HookSide.Both)
                leftHookName = hookType;

            // Right (သို့) Both Checkbox မှန်နေရင် Right Hook ထည့်မယ်
            if (dto.HookSide == HookSide.Right || dto.HookSide == HookSide.Both)
                rightHookName = hookType;
        }

        // Builder ထံသို့ Hook များကို တစ်ကြိမ်တည်း ပေးပို့ခြင်း
        builder.SetExternalHHooks(leftHookName, rightHookName, hookOri, hookOri)
               .SetInternalHHooks(leftHookName, rightHookName, hookOri, hookOri);

        // 1. Rebar များ ဖန်တီးခြင်း
        var result = builder.Build();

        //2. ⭐ Rebar Elements များပေါ်သို့ Level, Sign, Product, Ton Parameter များကို တိုက်ရိုက် ရေးသွင်းခြင်း
        ApplyScheduleParametersToRebars(result, hostWall, cleanWallName);

        return result;
        //return builder.Build();
    }

    // ⭐ Schedule အတွက် Parameter သီးသန့်သွင်းပေးသည့် Helper Method
    private void UpdateScheduleParameters(Autodesk.Revit.DB.Wall wall, RebarDto dto)
    {
        // Parameter နာမည်များသည် Revit ထဲရှိ Shared/Project Parameter နာမည်များနှင့် တူရပါမည်

        // 1. Selected_Diameter ကို သွင်းခြင်း (Revit သည် internal unit feet သုံးသောကြောင့် 304.8 နှင့် စားပေးရန်)
        Parameter pDia = wall.LookupParameter("Selected_Diameter");
        if (pDia != null)
        {
            pDia.Set(dto.SelectedDiameter / 304.8);
        }

        // 2. Selected_MPa ကို သွင်းခြင်း
        Parameter pMpa = wall.LookupParameter("Selected_MPa");
        if (pMpa != null)
        {
            pMpa.Set(dto.SelectedMPa);
        }
    }

    private void ApplyScheduleParametersToRebars(
    RebarSetsResultDto result,
    Autodesk.Revit.DB.Wall hostWall,
    string cleanWallName)
    {
        if (result == null || hostWall == null) return;

        // 1. Host Wall ၏ Level Name ကို ရယူခြင်း
        string levelName = "No Level";
        Level level = hostWall.Document.GetElement(hostWall.LevelId) as Level;
        if (level == null)
        {
            Parameter baseConstraint = hostWall.get_Parameter(BuiltInParameter.WALL_BASE_CONSTRAINT);
            if (baseConstraint != null && baseConstraint.AsElementId() != ElementId.InvalidElementId)
            {
                level = hostWall.Document.GetElement(baseConstraint.AsElementId()) as Level;
            }
        }
        if (level != null) levelName = level.Name.Trim();

        // 2. Build လုပ်ထားသော Rebar Element များကို စုစည်းခြင်း
        var rebars = new List<Autodesk.Revit.DB.Structure.Rebar>
        {
            result.ExternalVertical,
            result.InternalVertical,
            result.ExternalHorizontal,
            result.InternalHorizontal,
            result.UBar,
            result.LeftUBar
        };

        // ⭐ CapTies များကိုပါ စာရင်းထဲသို့ ပေါင်းထည့်ပါ
        if (result.CapTies != null && result.CapTies.Count > 0)
        {
            rebars.AddRange(result.CapTies);
        }

        var validRebars = rebars.Where(r => r != null).ToList();

        foreach (var rebar in validRebars)
        {
            // Level (LL Parameter ထဲသို့ ထည့်ခြင်း)
            Parameter pLevel = rebar.LookupParameter("레벨(층)") ?? rebar.LookupParameter("LL");
            if (pLevel != null && !pLevel.IsReadOnly)
            {
                pLevel.Set(levelName);
            }

            // Sign Name -> Full Wall Name ထည့်သွင်းခြင်း
            Parameter pSign = rebar.LookupParameter("Type") ?? rebar.LookupParameter("Sign Name");
            if (pSign != null && !pSign.IsReadOnly)
            {
                pSign.Set(hostWall.Name);
            }
            else
            {
                Parameter pMark = rebar.get_Parameter(BuiltInParameter.ALL_MODEL_MARK);
                pMark?.Set(hostWall.Name);
            }

            // Product နှင့် Ton တွက်ချက်၍ Rebar Parameter ထဲ ရေးသွင်းခြင်း
            var barType = rebar.Document.GetElement(rebar.GetTypeId()) as RebarBarType;
            if (barType != null)
            {
                double diameter = Math.Ceiling(UnitUtils.ConvertFromInternalUnits(barType.BarNominalDiameter, UnitTypeId.Millimeters));

                double product = diameter switch
                {
                    <= 10 => 0.00056,
                    <= 13 => 0.000995,
                    <= 16 => 0.00156,
                    <= 20 => 0.00247,
                    <= 25 => 0.00385,
                    <= 32 => 0.00631,
                    _ => (diameter * diameter / 162.0) / 1000.0
                };

                double rebarTotalLength = Math.Round(UnitUtils.ConvertFromInternalUnits(rebar.TotalLength, UnitTypeId.Meters), 3);
                double ton = Math.Round(rebarTotalLength * product, 3);

                // Product Parameter သို့ ရေးသွင်းခြင်း
                Parameter pProduct = rebar.LookupParameter("Product");
                if (pProduct != null && !pProduct.IsReadOnly)
                {
                    if (pProduct.StorageType == StorageType.String)
                        pProduct.Set(product.ToString("F6"));
                    else if (pProduct.StorageType == StorageType.Double)
                        pProduct.Set(product);
                }

                // Ton Parameter သို့ ရေးသွင်းခြင်း
                Parameter pTon = rebar.LookupParameter("Ton");
                if (pTon != null && !pTon.IsReadOnly)
                {
                    if (pTon.StorageType == StorageType.String)
                        pTon.Set(ton.ToString("F3"));
                    else if (pTon.StorageType == StorageType.Double)
                        pTon.Set(ton);
                }
            }
        }
    }
}