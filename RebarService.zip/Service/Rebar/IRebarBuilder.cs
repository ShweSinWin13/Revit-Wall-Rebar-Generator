using Structural_WinForm_Project_Sky_K_Solution.Models;
using SkyK.MPaManager;

namespace Structural_WinForm_Project_Sky_K_Solution.Service.Rebar;

public interface IRebarBuilder
{
    IRebarBuilder SetHost(Autodesk.Revit.DB.Wall hostElement);
    IRebarBuilder SetRebarDto(RebarDto rebarDto);
    IRebarBuilder SetGeometry(); 
    IRebarBuilder SetRebarType(string wallName, double internalVBarDia,double externalVBarDia,double internalHBarDia,double externalHBarDia,double uBarDiameter);
    IRebarBuilder SetCover(double cover);
    IRebarBuilder SetSpacing(double internalVBarSpacing,double externalVBarSpacing,double internalHBarSpacing,double externalHBarSpacing,double uBarSpacing);
    
    IRebarBuilder SetRebarShape();
    IRebarBuilder SetExternalVHooks(string startHookType, string endHookType, string startHookOrientation, string endHookOrientation);
    IRebarBuilder SetInternalVHooks(string startHookType, string endHookType, string startHookOrientation, string endHookOrientation);
    IRebarBuilder SetExternalHHooks(string startHookType, string endHookType, string startHookOrientation, string endHookOrientation);
    IRebarBuilder SetInternalHHooks(string startHookType, string endHookType, string startHookOrientation, string endHookOrientation);

    IRebarBuilder SetExternalVLengths(double anchorLength, double jointLength);
    IRebarBuilder SetInternalVLengths(double anchorLength, double jointLength);
    IRebarBuilder SetExternalHLengths(double leftAnchorLength, double rightAnchorLength);
    IRebarBuilder SetInternalHLengths(double leftAnchorLength, double rightAnchorLength);

    IRebarBuilder SetExternalVSlab(double belowFt, double topFt);
    IRebarBuilder SetInternalVSlab(double belowFt, double topFt);
    IRebarBuilder SetExternalHSlab(double leftFt, double rightFt);
    IRebarBuilder SetInternalHSlab(double leftFt, double rightFt);

    IRebarBuilder SetUBarSide(bool isUbar, UBarSide side);

    IRebarBuilder SetFoundationThickness(double foundationTHK);
    IRebarBuilder SetLowestJoint(double lowestJoint);

    IRebarBuilder SetSlabTHK(double slabTHK);

    IRebarBuilder SetMiddleFloorLengths(double internalJointLength, double externalJointLength);

    IRebarBuilder SetFoundationTHK(double foundationTHKO);

    RebarSetsResultDto Build();
}
