using Autodesk.Revit.DB;
using SkyK.MPaManager;
using Structural_WinForm_Project_Sky_K_Solution.Helpers;
using Structural_WinForm_Project_Sky_K_Solution.Models.ElementModel;
using Structural_WinForm_Project_Sky_K_Solution.Repository.WallRepository;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Structural_WinForm_Project_Sky_K_Solution.Service.WallService;

public class WallElementService
{
    private readonly WallElementRepo _wallRepo;
    private readonly Document _doc;
    
    public WallElementService(Document doc)
    {
        _doc = doc;
        _wallRepo = new WallElementRepo(_doc);
    }

    public List<ElementModel> GetWalls()
    {
        var result = new List<ElementModel>();
        
        var walls = _wallRepo.GetAll() ?? throw new InvalidOperationException("Failed to retrieve walls.");
        
        // Empty is valid → return empty
        if (walls.Count == 0) return result;
        
        foreach (var wall in walls)
        {
            if (wall == null) throw new InvalidOperationException("Wall collection contains null item.");
            
            var level = _doc.GetElement(wall.LevelId) as Level;
            var wallType = _doc.GetElement(wall.GetTypeId()) as WallType;
            
            var typeName = wallType?.Name ?? "Unknown Type";
            var levelName = level?.Name ?? "Unknown Level";

            result.Add(new ElementModel
            {
                Id = wall.Id,
                DisplayName = $"{typeName} - {levelName}"
            });
        }

        return result;
    }

    /*public static void SetWallNameAndTag(Document doc, Wall wall)
    {
        try
        {
            // Active View ပေါ်မှာ Tag အလိုအလျောက် တပ်ပေးပါမယ် (Floor Plan/ Structural Plan)
            Autodesk.Revit.DB.View activeView = doc.ActiveView;

            // Plan View (Floor Plan / Structural Plan) ထဲမှာပဲ Text ရေးပါမယ်
            if (activeView is ViewPlan)
            {
                // Tag ကို Wall ရဲ့ အလယ်ဗဟိုမှာ ပေါ်စေချင်လို့ပါ
                LocationCurve locCurve = wall.Location as LocationCurve;

                if (locCurve != null)
                {
                    // ၁။ Wall ရဲ့ ဗဟိုမှတ် (Center Point) ကို ရှာပါမယ်
                    XYZ midPoint = locCurve.Curve.Evaluate(0.5, true);

                    // ၂။ Properties ထဲက Wall Type Name ကို တိုက်ရိုက်ယူပါမယ် (ဥပမာ "2__A-HW9_220mm")
                    string wallTypeName = wall.WallType.Name;

                    // ၃။ Wall ရဲ့ အလယ်ဗဟို (၂ ပေပတ်လည်) မှာ ရှိနေတဲ့ TextNote အဟောင်းတွေကို လိုက်ရှာပြီး ဖျက်ပစ်ပါမယ်
                    FilteredElementCollector textCollector = new FilteredElementCollector(doc, activeView.Id)
                        .OfClass(typeof(TextNote));

                    foreach (TextNote tn in textCollector.Cast<TextNote>())
                    {
                        // တည်နေရာ အနီးအနားတူညီရင် အဟောင်းလို့ သတ်မှတ်ပြီး ဖျက်ပါတယ် (စာသားထပ်မနေစေရန်)
                        if (tn.Coord.DistanceTo(midPoint) < 2.0)
                        {
                            doc.Delete(tn.Id);
                        }
                    }

                    // ၄။ စာသား ပေါ်မယ့် ပုံစံကို သတ်မှတ်ခြင်း (အလယ်တည့်တည့် Alignment ဖြစ်အောင်)
                    TextNoteOptions options = new TextNoteOptions
                    {
                        VerticalAlignment = VerticalTextAlignment.Middle,
                        HorizontalAlignment = HorizontalTextAlignment.Center,
                        TypeId = doc.GetDefaultElementTypeId(ElementTypeGroup.TextNoteType)
                    };

                    // ၅။ အမြဲတမ်း မြင်နေရမယ့် TextNote ကို ဆောက်ထားတဲ့ Wall ပေါ်မှာ တစ်ခါတည်း ဆောက်ပေးလိုက်ပါပြီ
                    TextNote.Create(doc, activeView.Id, midPoint, wallTypeName, options);
                }
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine("Text Note Creation Error: " + ex.Message);
        }
    }*/

    public static void SetWallNameAndTag(Document doc, Wall wall)
    {
        try
        {
            // Tag ကို Wall ရဲ့ အလယ်ဗဟိုမှာ ပေါ်စေချင်လို့ပါ
            LocationCurve locCurve = wall.Location as LocationCurve;
            if (locCurve != null)
            {
                // ၁။ Wall ရဲ့ ဗဟိုမှတ် (Center Point) ကို ရှာပါမယ်
                XYZ midPoint = locCurve.Curve.Evaluate(0.5, true);

                // ၂။ Level ကို ရှာပြီး Clean Level Name ကို ထုတ်ယူပါမည် (ဥပမာ "4F" သို့မဟုတ် "B1")
                Level wallLevel = doc.GetElement(wall.LevelId) as Level;
                if (wallLevel == null) return;
                string levelPrefix = LevelParserHelper.CleanLevelName(wallLevel.Name);

                // ၃။ Properties ထဲက Wall Type ရဲ့ မူရင်း Core Name ကို ယူပါမည် (ဥပမာ "W4")
                string coreTypeName = wall.WallType.Name;

                // ၄။ Plan view တွင် ပေါ်မည့် စာသားကို Level Prefix နှင့် Core Name ပေါင်းစပ်ပေးပါမည် (ဥပမာ "4F_W4")
                string displayTagText = $"{levelPrefix}_{coreTypeName}";

                // ၅။ Level ရဲ့ Elevation နဲ့ တူညီတဲ့ Plan View များကို အရင်ရှာပါမယ် (Level Id အနည်းငယ်လွဲနေရင်တောင် မိစေရန်))
                var matchingViews = new FilteredElementCollector(doc)
                .OfClass(typeof(ViewPlan))
                .Cast<ViewPlan>()
                .Where(v => !v.IsTemplate && (v.ViewType == ViewType.FloorPlan || v.ViewType == ViewType.EngineeringPlan))
                .Where(v =>
                {
                    if (v.GenLevel != null)
                    {
                        Level vLevel = doc.GetElement(v.GenLevel.Id) as Level;
                        // Elevation အတိအကျတူညီမှသာ ထို Level ရဲ့ View အဖြစ် သတ်မှတ်ပါမည်
                        return vLevel != null && Math.Abs(vLevel.Elevation - wallLevel.Elevation) < 0.01;
                    }
                    return false;
                })
                .ToList();

                // အကယ်၍ Elevation နဲ့ရှာလို့ မတွေ့သေးရင် အလွှာနာမည် (ဥပမာ "3F") ပါတဲ့ View တွေကို ထပ်ရှာပါမယ်
                if (!matchingViews.Any())
                {
                    matchingViews = new FilteredElementCollector(doc)
                        .OfClass(typeof(ViewPlan))
                        .Cast<ViewPlan>()
                        .Where(v => !v.IsTemplate &&
                                    (v.ViewType == ViewType.FloorPlan || v.ViewType == ViewType.EngineeringPlan) &&
                                    v.Name.Contains(wallLevel.Name))
                        .ToList();
                }

                // ၆။ စာသား ပေါ်မယ့် ပုံစံကို သတ်မှတ်ခြင်း (အလယ်တည့်တည့် Alignment ဖြစ်အောင်)
                ElementId textTypeId = doc.GetDefaultElementTypeId(ElementTypeGroup.TextNoteType);
                if (textTypeId == ElementId.InvalidElementId)
                {
                    var firstTextType = new FilteredElementCollector(doc)
                        .OfClass(typeof(TextNoteType))
                        .FirstElementId();
                    if (firstTextType != null) textTypeId = firstTextType;
                }
                TextNoteOptions options = new TextNoteOptions
                {
                    VerticalAlignment = VerticalTextAlignment.Middle,
                    HorizontalAlignment = HorizontalTextAlignment.Center,
                    TypeId = textTypeId
                };

                // ၇။ သက်ဆိုင်ရာ View တစ်ခုချင်းစီတိုင်းမှာ Text Note တွေကို လိုက်ရေးပေးခြင်း
                foreach (var view in matchingViews)
                {
                    // ထို View ထဲတွင် Wall ရဲ့ အလယ်ဗဟို (၂ ပေပတ်လည်) မှာ ရှိနေတဲ့ TextNote အဟောင်းတွေကို လိုက်ရှာပြီး ဖျက်ပစ်ပါမယ်
                    FilteredElementCollector textCollector = new FilteredElementCollector(doc, view.Id)
                        .OfClass(typeof(TextNote));

                    foreach (TextNote tn in textCollector.Cast<TextNote>())
                    {
                        // တည်နေရာ အနီးအနားတူညီရင် အဟောင်းလို့ သတ်မှတ်ပြီး ဖျက်ပါတယ် (စာသားထပ်မနေစေရန်)
                        if (tn.Coord.DistanceTo(midPoint) < 2.0)
                        {
                            doc.Delete(tn.Id);
                        }
                    }

                    // အမြဲတမ်း မြင်နေရမယ့် TextNote ကို သက်ဆိုင်ရာ Level ရဲ့ Plan View ပေါ်မှာ တစ်ခါတည်း ဆောက်ပေးလိုက်ပါပြီ
                    TextNote.Create(doc, view.Id, midPoint, displayTagText, options);
                }
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine("Text Note Creation Error: " + ex.Message);
        }
    }
}

/*
    walls == null → throw
    wall == null → throw
    walls.Count == 0 → return empty
*/