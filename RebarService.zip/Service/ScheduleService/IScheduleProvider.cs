using SkyK.MPaManager;
namespace Structural_WinForm_Project_Sky_K_Solution.Service.ScheduleService;

public interface IScheduleProvider<TModel>
{
    IList<TModel> GetSortedSchedules();
}