﻿using ClosedXML.Excel;
using Structural_WinForm_Project_Sky_K_Solution.Models.ScheduleModel;
using System.Collections.Generic;
using SkyK.MPaManager;

namespace Structural_WinForm_Project_Sky_K_Solution.Service.ScheduleService.RebarSchedule
{
    public class RebarScheduleExportService : IScheduleExporter<RebarScheduleModel>
    {
        public void Export(bool includeIndexFlag, IList<RebarScheduleModel> schedules, string filePath, bool includeHeaderFlag)
        {
            using var workbook = new XLWorkbook();
            var ws = workbook.Worksheets.Add("Rebar Schedule");

            // Header List ကို သန့်ရှင်းစွာ တည်ဆောက်ခြင်း (Index နှစ်ထပ်ဖြစ်ခြင်းကို ဖြေရှင်းထားပါသည်)
            var headers = new List<string>();

            // Only add Index column if checkbox is checked
            if (includeIndexFlag) headers.Add("Index"); // put Index at first column
            headers.AddRange(new[]
            {
                "Level", "SignName", "BarType", "Diameter(mm)", "Spacing(mm)",
                "TotalLength(m)", "Product", "Ton", "Quantity"
            });

            // Checkbox On ထားရင် Header မှာ ◉True◉ ဆိုပြီး ထပ်ထည့်မည်
            if (includeHeaderFlag) headers.Add("◉True◉");

            // Header များကို Excel Worksheet တွင် ထည့်သွင်းခြင်း
            for (int col = 0; col < headers.Count; col++)
            {
                ws.Cell(1, col + 1).Value = headers[col];
                ws.Cell(1, col + 1).Style.Font.Bold = true; // Header ကို Bold လုပ်ခြင်း
            }

            int currentRow = 2;

            foreach (var item in schedules)
            {
                int col = 1;

                // Index Column ပါဝင်ပါက ထည့်သွင်းခြင်း
                if (includeIndexFlag)
                {
                    if (item.SignName == "TOTAL")
                        ws.Cell(currentRow, col++).Value = ""; // TOTAL row အတွက် Index ကို အလွတ်ထားမည်
                    else
                        ws.Cell(currentRow, col++).Value = item.Index;
                }

                ws.Cell(currentRow, col++).Value = item.LevelName;
                ws.Cell(currentRow, col++).Value = item.SignName;

                // TOTAL Row နှင့် သာမန် Row ခွဲခြား၍ Value များရေးသွင်းခြင်း
                if (item.SignName == "TOTAL")
                {
                    ws.Cell(currentRow, col++).Value = ""; // BarType -> အလွတ်
                    ws.Cell(currentRow, col++).Value = ""; // Diameter -> အလွတ်
                    ws.Cell(currentRow, col++).Value = ""; // Spacing -> အလွတ်
                    ws.Cell(currentRow, col++).Value = item.TotalBarLength;  // TotalLength
                    ws.Cell(currentRow, col++).Value = "";  // Product -> အလွတ်

                    ws.Cell(currentRow, col).Value = item.Ton;
                    ws.Cell(currentRow, col++).Style.NumberFormat.Format = "0.000";

                    ws.Cell(currentRow, col++).Value = item.Quantity; // Quantity တန်ဖိုးမှန်ကန်စွာ ထွက်မည်

                    if (includeHeaderFlag)
                    {
                        ws.Cell(currentRow, col++).Value = "FALSE";
                    }

                    // TOTAL Row တစ်ခုလုံးကို Bold ပြုလုပ်ပြီး LightGray ဖြည့်ခြင်း
                    ws.Row(currentRow).Style.Font.Bold = true;
                    ws.Row(currentRow).Style.Fill.BackgroundColor = XLColor.LightGray;
                }
                else
                {
                    ws.Cell(currentRow, col++).Value = item.RebarType;
                    ws.Cell(currentRow, col++).Value = item.BarDiameter + " mm";
                    ws.Cell(currentRow, col++).Value = item.Spacing + " mm";
                    ws.Cell(currentRow, col++).Value = item.TotalBarLength;
                    ws.Cell(currentRow, col++).Value = item.Product;

                    ws.Cell(currentRow, col).Value = item.Ton;
                    ws.Cell(currentRow, col++).Style.NumberFormat.Format = "0.000";

                    ws.Cell(currentRow, col++).Value = item.Quantity;

                    if (includeHeaderFlag)
                    {
                        ws.Cell(currentRow, col++).Value = "FALSE";
                    }
                }

                currentRow++;
            }

            // စာသားအရှည်ပေါ်မူတည်ပြီး Column အကျယ်ကို Auto ချိန်ညှိပေးခြင်း
            ws.Columns().AdjustToContents();

            // Excel File အဖြစ် သိမ်းဆည်းခြင်း
            workbook.SaveAs(filePath);
        }
    }
}