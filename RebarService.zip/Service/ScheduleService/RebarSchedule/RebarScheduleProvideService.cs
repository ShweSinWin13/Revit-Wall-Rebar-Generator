﻿using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using SkyK.MPaManager;
using Structural_WinForm_Project_Sky_K_Solution.Helpers;
using Structural_WinForm_Project_Sky_K_Solution.Models.ScheduleModel;
using Structural_WinForm_Project_Sky_K_Solution.Repository.RebarRepository;

namespace Structural_WinForm_Project_Sky_K_Solution.Service.ScheduleService.RebarSchedule;

public class RebarScheduleProvideService : IScheduleProvider<RebarScheduleModel>
{
    private readonly RebarElementRepo _rebarElementRepo;

    public RebarScheduleProvideService(Document doc)
    {
        _rebarElementRepo = new RebarElementRepo(doc);
    }

    public IList<RebarScheduleModel> GetSortedSchedules()
    {
        var rebars = _rebarElementRepo.GetAll();
        var result = new List<RebarScheduleModel>();

        foreach (var rebar in rebars)
        {
            var rebarTotalLength = Math.Round(
                UnitUtils.ConvertFromInternalUnits(rebar.TotalLength, UnitTypeId.Meters), 3);

            double spacing;
            try
            {
                spacing = Math.Round(
                    UnitUtils.ConvertFromInternalUnits(rebar.MaxSpacing, UnitTypeId.Millimeters), 3);
            }
            catch
            {
                spacing = 0;
            }

            // ⭐ Sign Name from parameter
            string signName = rebar.Name;
            Parameter signNameParam = rebar.LookupParameter("Sign") ?? rebar.LookupParameter("Sign Name");
            if (signNameParam == null)
            {
                signNameParam = rebar.get_Parameter(BuiltInParameter.ALL_MODEL_MARK);
            }
            if (signNameParam != null && signNameParam.HasValue)
            {
                signName = signNameParam.AsString() ?? signName;
            }

            var host = rebar.Document.GetElement(rebar.GetHostId()) as Wall;
            string level = "No Level";
            if (host != null)
            {
                Parameter baseConstraintParam = host.get_Parameter(BuiltInParameter.WALL_BASE_CONSTRAINT);
                if (baseConstraintParam != null && baseConstraintParam.AsElementId() != ElementId.InvalidElementId)
                {
                    var baseLevelEl = rebar.Document.GetElement(baseConstraintParam.AsElementId()) as Level;
                    if (baseLevelEl != null) level = baseLevelEl.Name.Trim();
                }

                // Range case: wall type name contains "~" or "-"
                string wallTypeName = host.WallType?.Name ?? "";
                if (!string.IsNullOrEmpty(wallTypeName) && (wallTypeName.Contains("~") || wallTypeName.Contains("-")))
                {
                    var levels = new FilteredElementCollector(rebar.Document)
                                 .OfClass(typeof(Level))
                                 .Cast<Level>()
                                 .ToList();
                    foreach (var lv in levels)
                    {
                        if (LevelParserHelper.IsLevelInRange(rebar.Document, lv.Name, wallTypeName))
                        {
                            level = lv.Name.Trim();
                            break;
                        }
                    }
                }

                // fallback to host.LevelId
                if (level == "No Level")
                {
                    var levelElement = rebar.Document.GetElement(host.LevelId) as Level;
                    if (levelElement != null) level = levelElement.Name.Trim();
                }
            }

            var barType = rebar.Document.GetElement(rebar.GetTypeId()) as RebarBarType;
            if (barType == null)
                continue;

            var diameter = Math.Ceiling(
                UnitUtils.ConvertFromInternalUnits(barType.BarNominalDiameter, UnitTypeId.Millimeters));

            // ⭐ Product from Comments parameter
            double product = 0.0;
            Parameter productParam = rebar.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS);
            if (productParam != null && productParam.HasValue)
            {
                double.TryParse(productParam.AsString(), out product);
            }
            if (product <= 0)
            {
                product = diameter switch
                {
                    <= 10 => 0.00056,
                    <= 13 => 0.000995,
                    <= 16 => 0.00156,
                    <= 20 => 0.00247,
                    <= 25 => 0.00385,
                    <= 32 => 0.00631,
                    _ => (diameter * diameter / 162.0) / 1000.0
                };
            }

            // ⭐ Ton from Description parameter
            double ton = 0.0;
            Parameter tonParam = rebar.get_Parameter(BuiltInParameter.ALL_MODEL_DESCRIPTION);
            if (tonParam != null && tonParam.HasValue)
            {
                double.TryParse(tonParam.AsString(), out ton);
            }
            if (ton <= 0)
            {
                ton = Math.Round(rebarTotalLength * product, 3);
            }

            // Quantity
            int quantity = rebar.Quantity;
            if (quantity == 0)
            {
                quantity = spacing > 0 ? (int)Math.Round((rebarTotalLength * 1000) / spacing) : 1;
            }

            result.Add(new RebarScheduleModel
            {
                LevelName = level,
                SignName = signName,           // <-- SignName from parameter
                RebarType = barType.Name,      // <-- RebarType from barType
                BarDiameter = diameter,
                Spacing = spacing,
                TotalBarLength = rebarTotalLength,
                Product = product,
                Ton = Math.Round(ton, 3),
                Quantity = quantity
            });
        }

        // Group rows
        var groupedResult = result
            .GroupBy(x => new { x.LevelName, x.SignName })
            .Select(g => new RebarScheduleModel
            {
                LevelName = g.Key.LevelName,
                RebarType = g.First().RebarType,
                SignName = g.Key.SignName,
                BarDiameter = g.First().BarDiameter,
                Spacing = g.First().Spacing,
                TotalBarLength = g.Sum(x => x.TotalBarLength),
                Product = g.First().Product,
                Ton = Math.Round(g.Sum(x => x.Ton), 3),
                Quantity = g.Sum(x => x.Quantity)
            })
            .OrderBy(x => x.LevelName)
            .ThenBy(x => x.BarDiameter)
            .ToList();

        // Add TOTAL row per Level
        var finalList = new List<RebarScheduleModel>();
        int indexCounter = 1;

        foreach (var group in groupedResult.GroupBy(x => x.LevelName))
        {
            foreach (var item in group)
            {
                item.Index = indexCounter++;
                finalList.Add(item);
            }

            var totalLength = Math.Round(group.Sum(x => x.TotalBarLength), 3);
            var totalTon = Math.Round(group.Sum(x => x.Ton), 3);
            var totalQty = group.Sum(x => x.Quantity);

            finalList.Add(new RebarScheduleModel
            {
                Index = 0,
                LevelName = group.Key,
                SignName = "TOTAL",
                TotalBarLength = totalLength,
                Ton = totalTon,
                Quantity = totalQty
            });
        }

        return finalList;
    }

}
