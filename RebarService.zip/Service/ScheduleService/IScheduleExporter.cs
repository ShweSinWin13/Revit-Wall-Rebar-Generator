using SkyK.MPaManager;
namespace Structural_WinForm_Project_Sky_K_Solution.Service.ScheduleService;

public interface IScheduleExporter<TModel>
{
    void Export(bool includeIndexFlag, IList<TModel> schedules, string filePath, bool includeHeaderFlag);
}